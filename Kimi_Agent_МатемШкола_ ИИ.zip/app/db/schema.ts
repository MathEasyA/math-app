import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  bigint,
  int,
  boolean,
  json,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
  /** Доступ к практике оплачен до этой даты; NULL — доступ закрыт */
  accessUntil: timestamp("accessUntil"),
  /** true, пока действует бесплатный пробный период (неделя новому ученику); сбрасывается при выдаче доступа учителем */
  trialGranted: boolean("trialGranted").notNull().default(false),
  /** Класс, в котором учится ученик (8–11); NULL — ещё не указал */
  grade: int("grade"),
  /** Режим: free — свободный банк заданий и тем, course — обучение с поэтапным открытием тем */
  learningMode: mysqlEnum("learningMode", ["free", "course"]),
  /** Входное тестирование пройдено */
  placementDone: boolean("placementDone").notNull().default(false),
  /** Результат входного теста: верных ответов */
  placementScore: int("placementScore"),
  /** Результат входного теста: всего заданий */
  placementTotal: int("placementTotal"),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/** Сгенерированное ИИ задание (ответ и решение хранятся на сервере) */
export const tasks = mysqlTable("tasks", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  sectionId: varchar("sectionId", { length: 32 }).notNull(),
  topicId: varchar("topicId", { length: 64 }).notNull(),
  difficulty: int("difficulty").notNull().default(2), // 1 — легко, 2 — средне, 3 — сложно
  question: text("question").notNull(),
  answer: varchar("answer", { length: 512 }).notNull(),
  solution: text("solution").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Task = typeof tasks.$inferSelect;

/** Попытка решения задания учеником */
export const attempts = mysqlTable("attempts", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  taskId: bigint("taskId", { mode: "number", unsigned: true }).notNull(),
  sectionId: varchar("sectionId", { length: 32 }).notNull(),
  topicId: varchar("topicId", { length: 64 }).notNull(),
  givenAnswer: varchar("givenAnswer", { length: 512 }).notNull(),
  correct: boolean("correct").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Attempt = typeof attempts.$inferSelect;

/** Отметка «теория темы изучена» */
export const theoryReads = mysqlTable("theoryReads", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  sectionId: varchar("sectionId", { length: 32 }).notNull(),
  topicId: varchar("topicId", { length: 64 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type TheoryRead = typeof theoryReads.$inferSelect;

/** Итог теста по теме (серия ИИ-заданий); passed = ошибок ≤ 20 % */
export const topicTests = mysqlTable("topicTests", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  sectionId: varchar("sectionId", { length: 32 }).notNull(),
  topicId: varchar("topicId", { length: 64 }).notNull(),
  correct: int("correct").notNull(),
  total: int("total").notNull(),
  passed: boolean("passed").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type TopicTest = typeof topicTests.$inferSelect;

/** Контрольная работа (режим обучения): создаёт учитель, решения ученику не показываются */
export const examWorks = mysqlTable("exam_works", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 200 }).notNull(),
  grade: int("grade").notNull(),
  /** id тем класса, которые входят в контрольную */
  topicIds: json("topicIds").$type<string[]>().notNull(),
  status: mysqlEnum("status", ["active", "closed"]).notNull().default("active"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ExamWork = typeof examWorks.$inferSelect;

/** Задание контрольной работы (генерируется один раз при создании — у всех одинаковые) */
export const examWorkTasks = mysqlTable("exam_work_tasks", {
  id: serial("id").primaryKey(),
  workId: bigint("workId", { mode: "number", unsigned: true }).notNull(),
  topicId: varchar("topicId", { length: 64 }).notNull(),
  orderIndex: int("orderIndex").notNull(),
  question: text("question").notNull(),
  answer: varchar("answer", { length: 512 }).notNull(),
});

export type ExamWorkTask = typeof examWorkTasks.$inferSelect;

/** Попытка прохождения контрольной: пока не завершена — темы ученика закрыты */
export const examWorkAttempts = mysqlTable("exam_work_attempts", {
  id: serial("id").primaryKey(),
  workId: bigint("workId", { mode: "number", unsigned: true }).notNull(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  startedAt: timestamp("startedAt").defaultNow().notNull(),
  finishedAt: timestamp("finishedAt"),
  correct: int("correct"),
  total: int("total"),
  /** Ответы ученика по заданиям (для разбора учителем) */
  details: json("details").$type<{ taskId: number; given: string; correct: boolean }[]>(),
});

export type ExamWorkAttempt = typeof examWorkAttempts.$inferSelect;

/** Обратная связь от учеников (вопросы, предложения) */
export const feedback = mysqlTable("feedback", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  category: mysqlEnum("category", ["question", "suggestion", "problem"]).notNull().default("question"),
  message: text("message").notNull(),
  read: boolean("read").notNull().default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Feedback = typeof feedback.$inferSelect;

/** Настройки сайта (одна строка, редактирует владелец) */
export const settings = mysqlTable("settings", {
  id: serial("id").primaryKey(),
  telegramBotToken: varchar("telegramBotToken", { length: 128 }),
  telegramChatId: varchar("telegramChatId", { length: 64 }),
  /** Текст о цене и оплате на экране закрытого доступа */
  priceText: text("priceText"),
  /** Контакты учителя на экране закрытого доступа */
  contactText: text("contactText"),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Settings = typeof settings.$inferSelect;
