import { Routes, Route } from "react-router";
import { AppShell } from "@/components/AppShell";
import Home from "./pages/Home";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";
import GradePage from "./pages/GradePage";
import TopicPage from "./pages/TopicPage";
import ExamsPage from "./pages/ExamsPage";
import ExamPage from "./pages/ExamPage";
import PracticePage from "./pages/PracticePage";
import ExamWorkPage from "./pages/ExamWorkPage";
import ProgressPage from "./pages/ProgressPage";
import FeedbackPage from "./pages/FeedbackPage";
import AdminPage from "./pages/AdminPage";
import UsersPage from "./pages/UsersPage";

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route
        path="*"
        element={
          <AppShell>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/class/:grade" element={<GradePage />} />
              <Route path="/class/:grade/topic/:topicId" element={<TopicPage />} />
              <Route path="/exams" element={<ExamsPage />} />
              <Route path="/exams/:examId" element={<ExamPage />} />
              <Route path="/practice/:sectionId/:topicId" element={<PracticePage />} />
              <Route path="/exam-work/:workId" element={<ExamWorkPage />} />
              <Route path="/progress" element={<ProgressPage />} />
              <Route path="/feedback" element={<FeedbackPage />} />
              <Route path="/admin" element={<AdminPage />} />
              <Route path="/users" element={<UsersPage />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </AppShell>
        }
      />
    </Routes>
  );
}
