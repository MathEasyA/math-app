import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sigma } from "lucide-react";
import { Link } from "react-router";
import { trpc } from "@/providers/trpc";

function getOAuthUrl() {
  const kimiAuthUrl = import.meta.env.VITE_KIMI_AUTH_URL;
  const appID = import.meta.env.VITE_APP_ID;
  const redirectUri = `${window.location.origin}/api/oauth/callback`;
  const state = btoa(redirectUri);

  const url = new URL(`${kimiAuthUrl}/api/oauth/authorize`);
  url.searchParams.set("client_id", appID);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "profile");
  url.searchParams.set("state", state);

  return url.toString();
}

export default function Login() {
  const infoQuery = trpc.teacher.publicInfo.useQuery();
  const info = infoQuery.data;

  return (
    <div className="flex min-h-dvh items-center justify-center bg-background p-4">
      <Card className="w-full max-w-sm rounded-3xl">
        <CardHeader className="items-center text-center">
          <span className="mb-2 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground">
            <Sigma className="h-7 w-7" aria-hidden />
          </span>
          <CardTitle className="font-display text-2xl">MathEasy</CardTitle>
          <p className="text-sm text-muted-foreground">
            Закрытое приложение для учеников. Войдите — теория открыта сразу, а практика с ИИ — бесплатно на первую неделю, дальше после подтверждения оплаты учителем.
          </p>
          <p className="rounded-xl bg-success/10 px-4 py-2.5 text-xs font-bold text-success">
            Новым ученикам — 7 дней полного доступа бесплатно
          </p>
          {info?.priceText && (
            <p className="mt-2 whitespace-pre-line rounded-xl bg-accent/60 px-4 py-3 text-left text-xs leading-relaxed text-foreground">
              {info.priceText}
            </p>
          )}
        </CardHeader>
        <CardContent className="flex flex-col gap-3">
          <Button
            className="min-h-12 w-full"
            size="lg"
            onClick={() => {
              window.location.href = getOAuthUrl();
            }}
          >
            Войти через Kimi
          </Button>
          <Link
            to="/"
            className="inline-flex min-h-11 items-center justify-center text-sm font-semibold text-muted-foreground transition-colors hover:text-foreground"
          >
            Продолжить без входа — читать теорию
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
