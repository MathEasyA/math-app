import { Link, useNavigate, useParams } from "react-router";
import { ArrowLeft, BookOpen, CheckCircle2, ClipboardCheck, Loader2, Lock, LogIn, RefreshCw, Send, Sparkles, XCircle } from "lucide-react";
import { useEffect, useRef, useState } from "react";

import { findExam, findGrade, findPracticeTarget } from "@contracts/content";
import { AccessLocked } from "@/components/AccessLocked";
import { MathParagraphs, MathText } from "@/components/MathText";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import NotFound from "./NotFound";

const DIFFICULTIES = [
  { value: 1, label: "Легко" },
  { value: 2, label: "Средне" },
  { value: 3, label: "Сложно" },
] as const;

function GateStep({ done, title, hint, last }: { done: boolean; title: string; hint: string; last?: boolean }) {
  return (
    <li className="flex items-start gap-3">
      <span
        className={`mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-xs font-bold ${
          done ? "bg-success text-success-foreground" : "border-2 border-muted-foreground/40 text-muted-foreground"
        }`}
        aria-hidden
      >
        {done ? "✓" : ""}
      </span>
      <span>
        <span className={`block text-sm font-bold ${done ? "text-success" : last ? "text-muted-foreground" : "text-foreground"}`}>{title}</span>
        <span className="block text-xs text-muted-foreground">{hint}</span>
      </span>
    </li>
  );
}

type Phase =
  | { kind: "idle" }
  | { kind: "loading" }
  | { kind: "answering"; taskId: number; question: string }
  | { kind: "checked"; taskId: number; question: string; correct: boolean; answer: string; solution: string };

export default function PracticePage() {
  const { sectionId = "", topicId = "" } = useParams<{ sectionId: string; topicId: string }>();
  const target = findPracticeTarget(sectionId, topicId);
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const navigate = useNavigate();
  const utils = trpc.useUtils();
  const accessQuery = trpc.teacher.myAccess.useQuery(undefined, { enabled: isAuthenticated });
  const access = accessQuery.data;
  const isAdmin = user?.role === "admin";
  const gateQuery = trpc.learning.topicGate.useQuery(
    { sectionId, topicId },
    { enabled: isAuthenticated && !isAdmin && !!target },
  );
  const gate = gateQuery.data;
  const examWork = !isAdmin ? gate?.examWork : null;
  const topicUnlocked = isAdmin || (gate?.unlocked ?? false);

  const [difficulty, setDifficulty] = useState<number>(2);
  const [phase, setPhase] = useState<Phase>({ kind: "idle" });
  const [answer, setAnswer] = useState("");
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [session, setSession] = useState({ solved: 0, correct: 0 });
  const inputRef = useRef<HTMLInputElement>(null);

  const generateMutation = trpc.tasks.generate.useMutation({
    onSuccess: (data) => {
      setPhase({ kind: "answering", taskId: data.taskId, question: data.question });
      setAnswer("");
      setErrorMsg(null);
    },
    onError: (err) => {
      setPhase({ kind: "idle" });
      setErrorMsg(err.message);
    },
  });

  const checkMutation = trpc.tasks.check.useMutation({
    onSuccess: (data, vars) => {
      setPhase((prev) => {
        if (prev.kind !== "answering") return prev;
        return {
          kind: "checked",
          taskId: vars.taskId,
          question: prev.question,
          correct: data.correct,
          answer: data.answer,
          solution: data.solution,
        };
      });
      setSession((s) => ({ solved: s.solved + 1, correct: s.correct + (data.correct ? 1 : 0) }));
      utils.tasks.progress.invalidate();
      utils.tasks.recentAttempts.invalidate();
    },
    onError: (err) => setErrorMsg(err.message),
  });

  useEffect(() => {
    if (phase.kind === "answering") inputRef.current?.focus();
  }, [phase.kind]);

  if (!target) return <NotFound />;

  const backLink = sectionId.startsWith("grade-")
    ? `/class/${sectionId.replace("grade-", "")}`
    : `/exams/${sectionId}?tab=practice`;
  const backLabel = sectionId.startsWith("grade-")
    ? (findGrade(Number(sectionId.replace("grade-", "")))?.title ?? "Назад")
    : `${findExam(sectionId)?.title ?? ""} · практика`;

  const startTask = () => {
    setErrorMsg(null);
    setPhase({ kind: "loading" });
    generateMutation.mutate({ sectionId, topicId, difficulty });
  };

  const submitAnswer = () => {
    if (phase.kind !== "answering" || !answer.trim()) return;
    checkMutation.mutate({ taskId: phase.taskId, answer: answer.trim() });
  };

  return (
    <div className="flex max-w-3xl flex-col gap-6">
      <div>
        <Link to={backLink} className="mb-4 inline-flex min-h-11 items-center gap-2 text-sm font-semibold text-muted-foreground transition-colors hover:text-foreground">
          <ArrowLeft className="h-4 w-4" aria-hidden /> {backLabel}
        </Link>
        <div className="flex flex-wrap items-center gap-3">
          <h1 className="font-display text-2xl font-semibold sm:text-3xl">{target.topicTitle}</h1>
          <Badge variant="secondary" className="gap-1"><Sparkles className="h-3 w-3" aria-hidden /> ИИ-практика</Badge>
        </div>
        <p className="mt-2 text-muted-foreground">{target.topicDescription}</p>
      </div>

      {/* Сложность + статистика сессии */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex gap-1.5 rounded-xl border bg-card p-1" role="group" aria-label="Уровень сложности">
          {DIFFICULTIES.map((d) => (
            <button
              key={d.value}
              onClick={() => setDifficulty(d.value)}
              aria-pressed={difficulty === d.value}
              className={`min-h-10 rounded-lg px-4 text-sm font-bold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
                difficulty === d.value ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-accent"
              }`}
            >
              {d.label}
            </button>
          ))}
        </div>
        {session.solved > 0 && (
          <p className="text-sm font-semibold text-muted-foreground">
            За эту сессию: <span className="text-foreground">{session.solved}</span> решено,{" "}
            <span className="text-success">{session.correct}</span> верно
          </p>
        )}
      </div>

      {errorMsg && (
        <div role="alert" className="rounded-2xl border border-destructive/40 bg-destructive/10 px-5 py-4 text-sm font-semibold text-destructive">
          {errorMsg}
        </div>
      )}

      {/* Требуется вход */}
      {!authLoading && !isAuthenticated && (
        <div className="rounded-3xl border bg-card p-8 text-center">
          <LogIn className="mx-auto h-10 w-10 text-primary" aria-hidden />
          <h2 className="font-display mt-4 text-xl font-semibold">Войдите, чтобы решать задания</h2>
          <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
            Генерация задач ИИ и сохранение прогресса доступны после входа через Kimi — это бесплатно и занимает пару секунд.
          </p>
          <Button className="mt-5 min-h-11" onClick={() => navigate("/login")}>Войти через Kimi</Button>
        </div>
      )}

      {/* Закрытый доступ */}
      {isAuthenticated && access && !access.hasAccess && (
        <AccessLocked accessUntil={access.accessUntil} />
      )}

      {/* Идёт контрольная работа — практика закрыта */}
      {isAuthenticated && (!access || access.hasAccess) && examWork && (
        <div className="rounded-3xl border bg-card p-8 text-center">
          <Lock className="mx-auto h-10 w-10 text-destructive" aria-hidden />
          <h2 className="font-display mt-4 text-xl font-semibold">Идёт контрольная работа</h2>
          <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
            Практика закрыта до сдачи контрольной «{examWork.title}» — чтобы никто не подглядывал.
          </p>
          <Link
            to={`/exam-work/${examWork.workId}`}
            className="mt-6 inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-bold text-primary-foreground transition-transform duration-200 hover:scale-[1.02] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            Перейти к контрольной
          </Link>
        </div>
      )}

      {/* Тема ещё не открыта: теория + тест */}
      {isAuthenticated && (!access || access.hasAccess) && !isAdmin && gate && !examWork && !topicUnlocked && (
        <div className="rounded-3xl border bg-card p-8 text-center">
          <Lock className="mx-auto h-10 w-10 text-primary" aria-hidden />
          <h2 className="font-display mt-4 text-xl font-semibold">Практика пока закрыта</h2>
          <ol className="mx-auto mt-4 flex max-w-md flex-col gap-3 text-left">
            {!gate.topicOpen && (
              <GateStep
                done={false}
                title="Сдайте тест по предыдущей теме"
                hint="В режиме обучения темы открываются по порядку"
              />
            )}
            <GateStep
              done={gate.theoryRead}
              title="Изучите теорию темы"
              hint="Прочитайте материал и нажмите «Теория изучена»"
            />
            <GateStep
              done={gate.testPassed}
              title="Сдайте проверочную работу"
              hint={`5 заданий, ошибок не больше 20%${gate.lastTest && !gate.lastTest.passed ? ` — прошлая попытка: ${gate.lastTest.correct} из ${gate.lastTest.total}` : ""}`}
            />
            <GateStep done={false} title="Практика с ИИ откроется" hint="Бесконечные задания по теме" last />
          </ol>
          {sectionId.startsWith("grade-") && (
            <Link
              to={`/class/${sectionId.replace("grade-", "")}/topic/${topicId}`}
              className="mt-6 inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-bold text-primary-foreground transition-transform duration-200 hover:scale-[1.02] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              {gate.theoryRead ? (
                <><ClipboardCheck className="h-4 w-4" aria-hidden /> К проверочной работе</>
              ) : (
                <><BookOpen className="h-4 w-4" aria-hidden /> К теории темы</>
              )}
            </Link>
          )}
          {!sectionId.startsWith("grade-") && (
            <Link
              to={backLink}
              className="mt-6 inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-bold text-primary-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              <ArrowLeft className="h-4 w-4" aria-hidden /> К теории раздела
            </Link>
          )}
        </div>
      )}

      {/* Старт */}
      {isAuthenticated && (!access || access.hasAccess) && topicUnlocked && phase.kind === "idle" && (
        <div className="rounded-3xl border bg-card p-8 text-center">
          <Sparkles className="mx-auto h-10 w-10 text-primary" aria-hidden />
          <h2 className="font-display mt-4 text-xl font-semibold">Готовы решать?</h2>
          <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
            ИИ составит новую задачу по теме «{target.topicTitle}» выбранной сложности.
            Каждый раз — новые числа и новый сюжет.
          </p>
          <Button className="mt-5 min-h-11" onClick={startTask} disabled={generateMutation.isPending}>
            Получить задание
          </Button>
        </div>
      )}

      {/* Генерация */}
      {isAuthenticated && (!access || access.hasAccess) && topicUnlocked && phase.kind === "loading" && (
        <div className="flex flex-col items-center gap-4 rounded-3xl border bg-card p-10 text-center" aria-live="polite">
          <Loader2 className="h-8 w-8 animate-spin text-primary" aria-hidden />
          <p className="font-semibold">ИИ составляет задачу…</p>
          <p className="text-sm text-muted-foreground">Обычно это занимает 5–15 секунд</p>
        </div>
      )}

      {/* Ответ на задание */}
      {isAuthenticated && (!access || access.hasAccess) && topicUnlocked && phase.kind === "answering" && (
        <div className="rounded-3xl border bg-card p-6 sm:p-8">
          <p className="mb-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">Задание</p>
          <div className="text-lg leading-relaxed"><MathText text={phase.question} /></div>
          <form
            className="mt-6 flex flex-col gap-3 sm:flex-row"
            onSubmit={(e) => {
              e.preventDefault();
              submitAnswer();
            }}
          >
            <input
              ref={inputRef}
              value={answer}
              onChange={(e) => setAnswer(e.target.value)}
              placeholder="Ваш ответ (число или дробь)"
              inputMode="text"
              autoComplete="off"
              className="min-h-12 flex-1 rounded-xl border bg-background px-4 text-base focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              aria-label="Ваш ответ"
            />
            <Button type="submit" className="min-h-12 gap-2" disabled={!answer.trim() || checkMutation.isPending}>
              {checkMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Send className="h-4 w-4" aria-hidden />}
              Проверить
            </Button>
          </form>
          <button
            onClick={startTask}
            disabled={generateMutation.isPending}
            className="mt-4 inline-flex min-h-11 items-center gap-2 text-sm font-semibold text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <RefreshCw className="h-4 w-4" aria-hidden /> Другое задание
          </button>
        </div>
      )}

      {/* Результат */}
      {isAuthenticated && (!access || access.hasAccess) && topicUnlocked && phase.kind === "checked" && (
        <div className="flex flex-col gap-4">
          <div
            className={`rounded-3xl border-2 p-6 sm:p-8 ${phase.correct ? "border-success/50 bg-success/10" : "border-destructive/40 bg-destructive/5"}`}
            aria-live="polite"
          >
            <div className="flex items-center gap-3">
              {phase.correct ? (
                <CheckCircle2 className="h-8 w-8 text-success" aria-hidden />
              ) : (
                <XCircle className="h-8 w-8 text-destructive" aria-hidden />
              )}
              <div>
                <p className="font-display text-xl font-semibold">{phase.correct ? "Верно!" : "Пока неверно"}</p>
                <p className="text-sm text-muted-foreground">
                  Правильный ответ: <span className="font-bold text-foreground"><MathText text={`$${phase.answer}$`} /></span>
                </p>
              </div>
            </div>
            <div className="mt-5 border-t pt-5">
              <p className="mb-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">Решение</p>
              <MathParagraphs text={phase.solution} className="leading-relaxed" />
            </div>
          </div>
          <div className="flex flex-col gap-2 sm:flex-row">
            <Button className="min-h-12 flex-1" onClick={startTask} disabled={generateMutation.isPending}>
              {generateMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden /> : null}
              Следующее задание
            </Button>
            <Button variant="outline" className="min-h-12 flex-1" onClick={() => navigate("/progress")}>
              Мой прогресс
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
