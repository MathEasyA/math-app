import { Link, useNavigate } from "react-router";
import { CheckCircle2, LineChart, LogIn, XCircle } from "lucide-react";

import { exams, grades } from "@contracts/content";
import { MathText } from "@/components/MathText";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";

const SECTION_TITLES: Record<string, string> = {
  ...Object.fromEntries(grades.map((g) => [`grade-${g.grade}`, g.title])),
  ...Object.fromEntries(exams.map((e) => [e.id, e.title])),
};

function topicTitle(sectionId: string, topicId: string): string {
  if (sectionId.startsWith("grade-")) {
    const g = grades.find((x) => `grade-${x.grade}` === sectionId);
    return g?.topics.find((t) => t.id === topicId)?.title ?? topicId;
  }
  const e = exams.find((x) => x.id === sectionId);
  return e?.practiceTopics.find((t) => t.id === topicId)?.title ?? topicId;
}

export default function ProgressPage() {
  const { isAuthenticated, isLoading } = useAuth();
  const navigate = useNavigate();
  const progressQuery = trpc.tasks.progress.useQuery(undefined, { enabled: isAuthenticated });
  const recentQuery = trpc.tasks.recentAttempts.useQuery(undefined, { enabled: isAuthenticated });

  if (!isLoading && !isAuthenticated) {
    return (
      <div className="rounded-3xl border bg-card p-8 text-center">
        <LogIn className="mx-auto h-10 w-10 text-primary" aria-hidden />
        <h1 className="font-display mt-4 text-xl font-semibold">Войдите, чтобы видеть прогресс</h1>
        <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
          Статистика решённых заданий сохраняется в вашем аккаунте и синхронизируется между устройствами.
        </p>
        <Button className="mt-5 min-h-11" onClick={() => navigate("/login")}>Войти через Kimi</Button>
      </div>
    );
  }

  const rows = progressQuery.data ?? [];
  const totals = rows.reduce((acc, r) => ({ solved: acc.solved + r.total, correct: acc.correct + r.correct }), { solved: 0, correct: 0 });
  const accuracy = totals.solved > 0 ? Math.round((totals.correct / totals.solved) * 100) : 0;

  const bySection = new Map<string, { solved: number; correct: number }>();
  for (const r of rows) {
    const cur = bySection.get(r.sectionId) ?? { solved: 0, correct: 0 };
    cur.solved += r.total;
    cur.correct += r.correct;
    bySection.set(r.sectionId, cur);
  }

  return (
    <div className="flex flex-col gap-8">
      <div>
        <h1 className="font-display flex items-center gap-3 text-3xl font-semibold">
          <LineChart className="h-7 w-7 text-primary" aria-hidden /> Мой прогресс
        </h1>
        <p className="mt-2 text-muted-foreground">Статистика по всем разделам и темам.</p>
      </div>

      {totals.solved === 0 && !progressQuery.isLoading ? (
        <div className="rounded-3xl border bg-card p-8 text-center">
          <p className="font-display text-xl font-semibold">Пока пусто</p>
          <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
            Решите первое задание — и здесь появится статистика.
          </p>
          <Link to="/class/8" className="mt-5 inline-flex min-h-11 items-center rounded-xl bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground">
            Выбрать тему
          </Link>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-3 gap-3">
            <StatCard label="Решено заданий" value={String(totals.solved)} />
            <StatCard label="Верных ответов" value={String(totals.correct)} />
            <StatCard label="Точность" value={`${accuracy}%`} />
          </div>

          <section aria-labelledby="sections-heading">
            <h2 id="sections-heading" className="font-display mb-3 text-xl font-semibold">По разделам</h2>
            <div className="flex flex-col gap-3">
              {[...bySection.entries()].map(([sectionId, s]) => {
                const pct = s.solved > 0 ? Math.round((s.correct / s.solved) * 100) : 0;
                return (
                  <div key={sectionId} className="rounded-2xl border bg-card p-4">
                    <div className="flex items-center justify-between gap-3">
                      <p className="font-bold">{SECTION_TITLES[sectionId] ?? sectionId}</p>
                      <p className="text-sm font-semibold text-muted-foreground">
                        {s.correct}/{s.solved} · {pct}%
                      </p>
                    </div>
                    <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-muted" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100} aria-label={`Точность: ${pct}%`}>
                      <div className="h-full rounded-full bg-primary transition-all duration-500" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          <section aria-labelledby="topics-heading">
            <h2 id="topics-heading" className="font-display mb-3 text-xl font-semibold">По темам</h2>
            <div className="overflow-hidden rounded-2xl border bg-card">
              {rows.map((r) => {
                const pct = r.total > 0 ? Math.round((r.correct / r.total) * 100) : 0;
                return (
                  <div key={`${r.sectionId}-${r.topicId}`} className="flex items-center justify-between gap-3 border-b px-4 py-3 last:border-0">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-bold">{topicTitle(r.sectionId, r.topicId)}</p>
                      <p className="text-xs text-muted-foreground">{SECTION_TITLES[r.sectionId] ?? r.sectionId}</p>
                    </div>
                    <p className={`shrink-0 text-sm font-bold ${pct >= 70 ? "text-success" : pct >= 40 ? "text-foreground" : "text-destructive"}`}>
                      {r.correct}/{r.total}
                    </p>
                  </div>
                );
              })}
            </div>
          </section>

          <section aria-labelledby="recent-heading">
            <h2 id="recent-heading" className="font-display mb-3 text-xl font-semibold">Последние задания</h2>
            <div className="flex flex-col gap-2">
              {(recentQuery.data ?? []).map((a) => (
                <div key={a.id} className="flex items-start gap-3 rounded-2xl border bg-card p-4">
                  {a.correct ? (
                    <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-success" aria-label="Верно" />
                  ) : (
                    <XCircle className="mt-0.5 h-5 w-5 shrink-0 text-destructive" aria-label="Неверно" />
                  )}
                  <div className="min-w-0 flex-1">
                    <p className="line-clamp-2 text-sm"><MathText text={a.question} /></p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {topicTitle(a.sectionId, a.topicId)} · ваш ответ: {a.givenAnswer} ·{" "}
                      {new Date(a.createdAt).toLocaleString("ru-RU", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </>
      )}
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border bg-card p-4 text-center sm:p-5">
      <p className="font-display text-2xl font-semibold sm:text-3xl">{value}</p>
      <p className="mt-1 text-[11px] text-muted-foreground sm:text-xs">{label}</p>
    </div>
  );
}
