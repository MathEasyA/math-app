import { Link } from "react-router";
import { ArrowRight, BookOpen, Infinity as InfinityIcon, Lock, Sparkles, Target, Timer } from "lucide-react";

import { exams, grades } from "@contracts/content";
import { Badge } from "@/components/ui/badge";
import { ExamWorkBanner } from "@/components/ExamWorkBanner";
import { Onboarding } from "@/components/Onboarding";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const progressQuery = trpc.tasks.progress.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  const accessQuery = trpc.teacher.myAccess.useQuery(undefined, { enabled: isAuthenticated });
  const access = accessQuery.data;
  const trialDaysLeft =
    access?.trialActive && access.accessUntil
      ? Math.max(1, Math.ceil((new Date(access.accessUntil).getTime() - Date.now()) / (24 * 60 * 60 * 1000)))
      : null;

  const totals = (progressQuery.data ?? []).reduce(
    (acc, row) => ({ solved: acc.solved + row.total, correct: acc.correct + row.correct }),
    { solved: 0, correct: 0 },
  );
  const accuracy = totals.solved > 0 ? Math.round((totals.correct / totals.solved) * 100) : null;

  const isAdmin = user?.role === "admin";
  const courseMode = !isAdmin && user?.learningMode === "course";
  const needsOnboarding =
    isAuthenticated &&
    !isAdmin &&
    (!user?.grade || !user?.learningMode || (user.learningMode === "course" && !user.placementDone));

  return (
    <div className="flex flex-col gap-10">
      {/* Первый вход: выбор класса и режима, для обучения — входное тестирование */}
      {needsOnboarding && (
        <Onboarding
          initialGrade={user?.grade ?? null}
          initialMode={user?.learningMode === "course" ? "course" : null}
        />
      )}
      {/* Активная контрольная работа */}
      {!needsOnboarding && <ExamWorkBanner />}
      {/* Пробный период */}
      {trialDaysLeft !== null && (
        <div
          className="flex flex-wrap items-center gap-3 rounded-3xl border-2 border-success/40 bg-success/5 p-4 sm:p-5"
          role="status"
        >
          <Timer className="h-7 w-7 shrink-0 text-success" aria-hidden />
          <p className="text-sm sm:text-base">
            <b>Пробный период:</b> полный доступ бесплатно ещё{" "}
            <b>{trialDaysLeft} {trialDaysLeft === 1 ? "день" : trialDaysLeft < 5 ? "дня" : "дней"}</b>
            {access?.accessUntil && (
              <span className="text-muted-foreground">
                {" "}— до {new Date(access.accessUntil).toLocaleDateString("ru-RU")}
              </span>
            )}
          </p>
        </div>
      )}
      {/* Приветствие */}
      <section className="rounded-3xl border bg-card p-6 sm:p-10">
        <Badge variant="secondary" className="mb-4">Математика · 8–11 классы</Badge>
        <h1 className="font-display max-w-2xl text-3xl font-semibold leading-tight sm:text-4xl">
          {isAuthenticated && user?.name ? `Привет, ${user.name.split(" ")[0]}! ` : ""}
          Математика без стресса: теория, бесконечная практика с ИИ и подготовка к ОГЭ и ЕГЭ
        </h1>
        <p className="mt-4 max-w-2xl text-muted-foreground">
          Выбирай свой класс, читай короткую теорию и решай задания — искусственный интеллект
          генерирует новые варианты по теме сколько угодно раз и показывает решение.
        </p>
        <div className="mt-6 flex flex-wrap gap-3">
          <Link
            to="/class/8"
            className="inline-flex min-h-11 items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground transition-transform duration-200 hover:scale-[1.02] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            Начать с класса <ArrowRight className="h-4 w-4" aria-hidden />
          </Link>
          <Link
            to="/exams"
            className="inline-flex min-h-11 items-center gap-2 rounded-xl border bg-card px-5 py-2.5 text-sm font-bold transition-colors hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <Target className="h-4 w-4" aria-hidden /> К экзаменам
          </Link>
        </div>

        {isAuthenticated && totals.solved > 0 && (
          <div className="mt-8 flex flex-wrap gap-6 border-t pt-6">
            <Stat label="Решено заданий" value={String(totals.solved)} />
            <Stat label="Точность" value={accuracy !== null ? `${accuracy}%` : "—"} />
          </div>
        )}
      </section>

      {/* Классы */}
      <section aria-labelledby="grades-heading">
        <h2 id="grades-heading" className="font-display mb-4 text-2xl font-semibold">Разделы по классам</h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {grades.map((g) => {
            const locked =
              isAuthenticated && courseMode && !needsOnboarding && user?.grade != null && user.grade !== g.grade;
            if (locked) {
              return (
                <div key={g.grade} className="relative rounded-3xl border bg-card/50 p-6 opacity-60" aria-disabled>
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h3 className="font-display text-xl font-semibold">{g.title}</h3>
                      <p className="mt-2 text-sm text-muted-foreground">{g.description}</p>
                    </div>
                    <span className="font-display text-5xl font-semibold text-primary/15">{g.grade}</span>
                  </div>
                  <p className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground">
                    <Lock className="h-3.5 w-3.5" aria-hidden /> Открыт ваш {user?.grade} класс
                  </p>
                </div>
              );
            }
            return (
              <Link
                key={g.grade}
                to={`/class/${g.grade}`}
                className="group rounded-3xl border bg-card p-6 transition-all duration-200 hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h3 className="font-display text-xl font-semibold">
                      {g.title}
                      {isAuthenticated && !isAdmin && user?.grade === g.grade && (
                        <Badge className="ml-2 align-middle">ваш класс</Badge>
                      )}
                    </h3>
                    <p className="mt-2 text-sm text-muted-foreground">{g.description}</p>
                  </div>
                  <span className="font-display text-5xl font-semibold text-primary/20 transition-colors group-hover:text-primary/40">
                    {g.grade}
                  </span>
                </div>
                <div className="mt-4 flex items-center gap-4 text-xs font-semibold text-muted-foreground">
                  <span className="inline-flex items-center gap-1.5"><BookOpen className="h-3.5 w-3.5" aria-hidden /> {g.topics.length} тем теории</span>
                  <span className="inline-flex items-center gap-1.5"><InfinityIcon className="h-3.5 w-3.5" aria-hidden /> практика с ИИ</span>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Экзамены */}
      <section aria-labelledby="exams-heading">
        <h2 id="exams-heading" className="font-display mb-4 text-2xl font-semibold">Экзамены</h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {exams.map((e) => (
            <Link
              key={e.id}
              to={`/exams/${e.id}`}
              className="group rounded-3xl border-2 border-primary/25 bg-primary/5 p-6 transition-all duration-200 hover:-translate-y-0.5 hover:border-primary/50 hover:shadow-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              <div className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-primary" aria-hidden />
                <h3 className="font-display text-xl font-semibold">{e.title}</h3>
              </div>
              <p className="mt-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">{e.subtitle}</p>
              <p className="mt-3 text-sm text-muted-foreground">{e.description}</p>
              <div className="mt-4 grid grid-cols-2 gap-2">
                {e.facts.slice(0, 2).map((f) => (
                  <div key={f.label} className="rounded-xl bg-card px-3 py-2 text-center">
                    <p className="font-display text-lg font-semibold">{f.value}</p>
                    <p className="text-[11px] text-muted-foreground">{f.label}</p>
                  </div>
                ))}
              </div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="font-display text-3xl font-semibold">{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  );
}
