import { useState } from "react";
import { Link, useParams } from "react-router";
import {
  ArrowLeft,
  CheckCircle2,
  ClipboardCheck,
  Lightbulb,
  Loader2,
  Lock,
  PenLine,
  Send,
  Trophy,
  XCircle,
} from "lucide-react";

import { findGrade, type TheoryBlock } from "@contracts/content";
import { MathText } from "@/components/MathText";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import NotFound from "./NotFound";

export default function TopicPage() {
  const { grade: gradeParam, topicId } = useParams<{ grade: string; topicId: string }>();
  const grade = findGrade(Number(gradeParam));
  const topic = grade?.topics.find((t) => t.id === topicId);
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const utils = trpc.useUtils();

  const sectionId = `grade-${grade?.grade ?? ""}`;
  const gateQuery = trpc.learning.topicGate.useQuery(
    { sectionId, topicId: topicId ?? "" },
    { enabled: isAuthenticated && !!topic },
  );
  const markRead = trpc.learning.markTheoryRead.useMutation({
    onSuccess: () => {
      utils.learning.topicGate.invalidate();
      utils.learning.topicStatuses.invalidate();
    },
  });

  if (!grade || !topic) return <NotFound />;

  const isAdmin = user?.role === "admin";
  const gate = gateQuery.data;
  // Цепочка теория → тест → практика действует только в режиме обучения
  const gated = isAuthenticated && !isAdmin && gate?.mode === "course";
  const topicLocked = gated && gate != null && !gate.topicOpen;
  const examWork = !isAdmin ? gate?.examWork : null;

  // Идёт контрольная работа — тема закрыта, чтобы не подглядывать
  if (examWork) {
    return (
      <div className="flex flex-col gap-6">
        <section className="rounded-3xl border bg-card p-8 text-center sm:p-12">
          <Lock className="mx-auto h-10 w-10 text-destructive" aria-hidden />
          <h1 className="font-display mt-4 text-2xl font-semibold">Идёт контрольная работа</h1>
          <p className="mx-auto mt-2 max-w-md text-muted-foreground">
            Доступ к темам закрыт до сдачи контрольной «{examWork.title}» — чтобы никто не подглядывал.
          </p>
          <Link
            to={`/exam-work/${examWork.workId}`}
            className="mt-6 inline-flex min-h-11 items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground transition-transform duration-200 hover:scale-[1.02] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            Перейти к контрольной
          </Link>
        </section>
      </div>
    );
  }

  if (topicLocked) {
    const idx = grade.topics.findIndex((t) => t.id === topic.id);
    const prev = idx > 0 ? grade.topics[idx - 1] : null;
    return (
      <div className="flex flex-col gap-6">
        <Link to={`/class/${grade.grade}`} className="inline-flex min-h-11 items-center gap-2 text-sm font-semibold text-muted-foreground transition-colors hover:text-foreground">
          <ArrowLeft className="h-4 w-4" aria-hidden /> {grade.title}
        </Link>
        <section className="rounded-3xl border bg-card p-8 text-center sm:p-12">
          <Lock className="mx-auto h-10 w-10 text-muted-foreground" aria-hidden />
          <h1 className="font-display mt-4 text-2xl font-semibold">Тема пока закрыта</h1>
          <p className="mx-auto mt-2 max-w-md text-muted-foreground">
            «{topic.title}» откроется после того, как будет сдан тест по предыдущей теме
            {prev ? <> — <b className="text-foreground">«{prev.title}»</b></> : ""}.
          </p>
          {prev && (
            <Link
              to={`/class/${grade.grade}/topic/${prev.id}`}
              className="mt-6 inline-flex min-h-11 items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground transition-transform duration-200 hover:scale-[1.02] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              Перейти к предыдущей теме
            </Link>
          )}
        </section>
      </div>
    );
  }

  return (
    <article className="flex max-w-3xl flex-col gap-6">
      <div>
        <Link to={`/class/${grade.grade}`} className="mb-4 inline-flex min-h-11 items-center gap-2 text-sm font-semibold text-muted-foreground transition-colors hover:text-foreground">
          <ArrowLeft className="h-4 w-4" aria-hidden /> {grade.title}
        </Link>
        <h1 className="font-display text-3xl font-semibold leading-tight">{topic.title}</h1>
        <p className="mt-2 text-muted-foreground">{topic.description}</p>
      </div>

      <div className="flex flex-col gap-4">
        {topic.theory.map((block, i) => (
          <TheoryBlockView key={i} block={block} />
        ))}
      </div>

      {/* Шаг 1: отметка о прочтении теории */}
      {gated && gate && !gate.theoryRead && (
        <div className="rounded-3xl border-2 border-primary/30 bg-primary/5 p-6 text-center">
          <BookOpenDone />
          <p className="font-display mt-3 text-xl font-semibold">Дочитали до конца?</p>
          <p className="mx-auto mt-1 max-w-md text-sm text-muted-foreground">
            Отметьте теорию как изученную — тогда откроется проверочная работа по теме.
          </p>
          <Button className="mt-4 min-h-12 gap-2 px-6" onClick={() => markRead.mutate({ sectionId, topicId: topic.id })} disabled={markRead.isPending}>
            {markRead.isPending ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <CheckCircle2 className="h-4 w-4" aria-hidden />}
            Теория изучена
          </Button>
        </div>
      )}
      {gated && gate?.theoryRead && (
        <p className="inline-flex items-center gap-2 self-start rounded-full bg-success/10 px-4 py-2 text-sm font-semibold text-success">
          <CheckCircle2 className="h-4 w-4" aria-hidden /> Теория изучена
        </p>
      )}

      {/* Шаг 2: тест по теме */}
      {gated && gate?.theoryRead && !gate.testPassed && (
        <TopicTest sectionId={sectionId} topicId={topic.id} lastTest={gate.lastTest} />
      )}
      {gated && !authLoading && !gate && gateQuery.isLoading && (
        <div className="flex justify-center p-4"><Loader2 className="h-5 w-5 animate-spin text-primary" aria-hidden /></div>
      )}

      {/* Шаг 3: практика (после теста в обучении; сразу в свободном режиме и для учителя) */}
      {(isAdmin || gate?.unlocked) && (
        <Link
          to={`/practice/${sectionId}/${topic.id}`}
          className="mt-2 inline-flex min-h-12 items-center justify-center gap-2 self-start rounded-xl bg-primary px-6 py-3 text-sm font-bold text-primary-foreground transition-transform duration-200 hover:scale-[1.02] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <PenLine className="h-4 w-4" aria-hidden /> Перейти к практике
        </Link>
      )}
      {gated && gate && !gate.testPassed && gate.theoryRead && (
        <p className="inline-flex items-center gap-2 text-sm text-muted-foreground">
          <Lock className="h-4 w-4" aria-hidden /> Практика откроется после сдачи теста (ошибок ≤ 20%)
        </p>
      )}

      {/* Не вошёл */}
      {!authLoading && !isAuthenticated && (
        <Link
          to="/login"
          className="inline-flex min-h-12 items-center justify-center gap-2 self-start rounded-xl border px-6 py-3 text-sm font-bold transition-colors hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          Войдите, чтобы открыть практику
        </Link>
      )}
    </article>
  );
}

function BookOpenDone() {
  return <ClipboardCheck className="mx-auto h-10 w-10 text-primary" aria-hidden />;
}

/* ---------------- Тест по теме ---------------- */

type TestPhase =
  | { kind: "start" }
  | { kind: "loading" }
  | { kind: "run"; questions: { taskId: number; question: string }[] }
  | { kind: "result"; correct: number; total: number; passed: boolean; review: { question: string; given: string; answer: string; correct: boolean }[] };

function TopicTest({
  sectionId,
  topicId,
  lastTest,
}: {
  sectionId: string;
  topicId: string;
  lastTest: { correct: number; total: number; passed: boolean } | null;
}) {
  const utils = trpc.useUtils();
  const [phase, setPhase] = useState<TestPhase>({ kind: "start" });
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const startMutation = trpc.learning.testStart.useMutation({
    onSuccess: (data) => {
      setAnswers({});
      setErrorMsg(null);
      setPhase({ kind: "run", questions: data.questions });
    },
    onError: (err) => {
      setErrorMsg(err.message);
      setPhase({ kind: "start" });
    },
  });

  const submitMutation = trpc.learning.testSubmit.useMutation({
    onSuccess: (data) => {
      setPhase({ kind: "result", correct: data.correct, total: data.total, passed: data.passed, review: data.review });
      utils.learning.topicGate.invalidate();
      utils.learning.topicStatuses.invalidate();
      utils.tasks.progress.invalidate();
      utils.tasks.recentAttempts.invalidate();
    },
    onError: (err) => setErrorMsg(err.message),
  });

  const start = () => {
    setErrorMsg(null);
    setPhase({ kind: "loading" });
    startMutation.mutate({ sectionId, topicId });
  };

  if (phase.kind === "start") {
    return (
      <section id="test" className="scroll-mt-24 rounded-3xl border-2 border-primary/30 bg-primary/5 p-6 sm:p-8">
        <ClipboardCheck className="h-9 w-9 text-primary" aria-hidden />
        <h2 className="font-display mt-3 text-2xl font-semibold">Проверочная работа</h2>
        <p className="mt-2 max-w-lg text-sm text-muted-foreground">
          5 заданий от ИИ, чтобы закрепить материал. Чтобы открыть бесконечную практику, нужно ошибиться <b className="text-foreground">не больше чем в 1 задании из 5</b> (20%).
        </p>
        {lastTest && (
          <p className="mt-3 rounded-xl bg-destructive/10 px-4 py-2.5 text-sm font-semibold text-destructive">
            Прошлая попытка: {lastTest.correct} из {lastTest.total} верно — нужно не меньше {Math.ceil(0.8 * lastTest.total)}. Попробуйте ещё раз!
          </p>
        )}
        <Button className="mt-4 min-h-12 gap-2 px-6" onClick={start}>
          {lastTest ? "Пройти ещё раз" : "Начать проверочную работу"}
        </Button>
        {errorMsg && <p role="alert" className="mt-3 text-sm font-semibold text-destructive">{errorMsg}</p>}
      </section>
    );
  }

  if (phase.kind === "loading") {
    return (
      <section className="flex flex-col items-center gap-4 rounded-3xl border bg-card p-10 text-center" aria-live="polite">
        <Loader2 className="h-8 w-8 animate-spin text-primary" aria-hidden />
        <p className="font-semibold">ИИ составляет тест…</p>
        <p className="text-sm text-muted-foreground">Обычно это занимает 10–20 секунд</p>
      </section>
    );
  }

  if (phase.kind === "run") {
    const allAnswered = phase.questions.every((q) => (answers[q.taskId] ?? "").trim().length > 0);
    return (
      <section className="flex flex-col gap-5 rounded-3xl border bg-card p-6 sm:p-8">
        <div>
          <h2 className="font-display text-2xl font-semibold">Проверочная работа</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Ответьте на все {phase.questions.length} заданий. Для зачёта — не больше 20% ошибок.
          </p>
        </div>
        <ol className="flex flex-col gap-5">
          {phase.questions.map((q, i) => (
            <li key={q.taskId} className="rounded-2xl bg-accent/40 p-4 sm:p-5">
              <p className="mb-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">Задание {i + 1}</p>
              <div className="leading-relaxed"><MathText text={q.question} /></div>
              <input
                value={answers[q.taskId] ?? ""}
                onChange={(e) => setAnswers((a) => ({ ...a, [q.taskId]: e.target.value }))}
                placeholder="Ваш ответ"
                autoComplete="off"
                className="mt-3 min-h-11 w-full max-w-xs rounded-xl border bg-background px-4 text-base focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                aria-label={`Ответ на задание ${i + 1}`}
              />
            </li>
          ))}
        </ol>
        <Button
          className="min-h-12 gap-2 self-start px-6"
          disabled={!allAnswered || submitMutation.isPending}
          onClick={() =>
            submitMutation.mutate({
              sectionId,
              topicId,
              answers: phase.questions.map((q) => ({ taskId: q.taskId, answer: (answers[q.taskId] ?? "").trim() })),
            })
          }
        >
          {submitMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Send className="h-4 w-4" aria-hidden />}
          Завершить тест
        </Button>
        {!allAnswered && <p className="text-xs text-muted-foreground">Ответьте на все задания, чтобы завершить тест.</p>}
        {errorMsg && <p role="alert" className="text-sm font-semibold text-destructive">{errorMsg}</p>}
      </section>
    );
  }

  /* Результат теста */
  const { correct, total, passed, review } = phase;
  return (
    <section className="flex flex-col gap-4" aria-live="polite">
      <div className={`rounded-3xl border-2 p-6 text-center sm:p-8 ${passed ? "border-success/50 bg-success/10" : "border-destructive/40 bg-destructive/5"}`}>
        {passed ? (
          <Trophy className="mx-auto h-12 w-12 text-success" aria-hidden />
        ) : (
          <XCircle className="mx-auto h-12 w-12 text-destructive" aria-hidden />
        )}
        <p className="font-display mt-3 text-2xl font-semibold">{passed ? "Проверочная сдана!" : "Пока не сдана"}</p>
        <p className="font-display mt-1 text-4xl font-semibold">{correct} из {total}</p>
        <p className="mt-2 text-sm text-muted-foreground">
          {passed
            ? "Бесконечная практика по теме открыта — кнопка ниже."
            : `Для зачёта нужно не меньше ${Math.ceil(0.8 * total)} верных (ошибок не больше 20%). Повторите теорию и попробуйте снова.`}
        </p>
        {!passed && (
          <Button className="mt-4 min-h-12 px-6" onClick={() => setPhase({ kind: "start" })}>
            Пройти ещё раз
          </Button>
        )}
      </div>

      <details className="rounded-2xl border bg-card p-5">
        <summary className="min-h-11 cursor-pointer text-sm font-bold">Разбор ответов</summary>
        <ol className="mt-3 flex flex-col gap-3">
          {review.map((r, i) => (
            <li key={i} className="rounded-xl bg-accent/40 p-4 text-sm">
              <div className="flex items-start gap-2">
                {r.correct ? (
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-success" aria-hidden />
                ) : (
                  <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" aria-hidden />
                )}
                <div className="min-w-0">
                  <MathText text={r.question} />
                  <p className="mt-2 text-muted-foreground">
                    Ваш ответ: <b className={r.correct ? "text-success" : "text-destructive"}>{r.given}</b>
                    {!r.correct && (
                      <> · верно: <b className="text-foreground"><MathText text={`$${r.answer}$`} /></b></>
                    )}
                  </p>
                </div>
              </div>
            </li>
          ))}
        </ol>
      </details>
    </section>
  );
}

export function TheoryBlockView({ block }: { block: TheoryBlock }) {
  switch (block.type) {
    case "p":
      return <p className="leading-relaxed"><MathText text={block.text} /></p>;
    case "formula":
      return (
        <div className="rounded-2xl border bg-accent/40 px-5 py-4 text-center text-lg">
          <MathText text={`$$${block.text}$$`} />
        </div>
      );
    case "list":
      return (
        <ul className="flex list-disc flex-col gap-2 pl-6 leading-relaxed marker:text-primary">
          {block.items.map((item, i) => (
            <li key={i}><MathText text={item} /></li>
          ))}
        </ul>
      );
    case "example":
      return (
        <div className="rounded-2xl border-l-4 border-primary bg-card p-5 shadow-sm">
          <p className="mb-1 flex items-center gap-2 text-sm font-bold text-primary">
            <Lightbulb className="h-4 w-4" aria-hidden /> {block.title}
          </p>
          <p className="leading-relaxed"><MathText text={block.text} /></p>
        </div>
      );
    case "note":
      return (
        <div className="rounded-2xl bg-secondary px-5 py-4 text-sm leading-relaxed text-secondary-foreground">
          <MathText text={block.text} />
        </div>
      );
    default:
      return null;
  }
}
