import { useNavigate } from "react-router";
import { CheckCircle2, HelpCircle, Lightbulb, Loader2, LogIn, MessageCircleQuestion, Send, TriangleAlert } from "lucide-react";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";

const CATEGORIES = [
  { value: "question", label: "Вопрос", icon: HelpCircle },
  { value: "suggestion", label: "Предложение", icon: Lightbulb },
  { value: "problem", label: "Проблема", icon: TriangleAlert },
] as const;

export default function FeedbackPage() {
  const { isAuthenticated, isLoading } = useAuth();
  const navigate = useNavigate();
  const [category, setCategory] = useState<(typeof CATEGORIES)[number]["value"]>("question");
  const [message, setMessage] = useState("");
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submitMutation = trpc.teacher.submitFeedback.useMutation({
    onSuccess: () => {
      setSent(true);
      setMessage("");
    },
    onError: (err) => setError(err.message),
  });

  if (!isLoading && !isAuthenticated) {
    return (
      <div className="rounded-3xl border bg-card p-8 text-center">
        <LogIn className="mx-auto h-10 w-10 text-primary" aria-hidden />
        <h1 className="font-display mt-4 text-xl font-semibold">Войдите, чтобы написать учителю</h1>
        <Button className="mt-5 min-h-11" onClick={() => navigate("/login")}>Войти через Kimi</Button>
      </div>
    );
  }

  return (
    <div className="flex max-w-2xl flex-col gap-6">
      <div>
        <h1 className="font-display flex items-center gap-3 text-3xl font-semibold">
          <MessageCircleQuestion className="h-7 w-7 text-primary" aria-hidden /> Обратная связь
        </h1>
        <p className="mt-2 text-muted-foreground">
          Вопрос по теме, идея, как улучшить приложение, или сообщение о проблеме — учитель получит ваше сообщение сразу.
        </p>
      </div>

      {sent ? (
        <div className="rounded-3xl border-2 border-success/50 bg-success/10 p-8 text-center" aria-live="polite">
          <CheckCircle2 className="mx-auto h-10 w-10 text-success" aria-hidden />
          <h2 className="font-display mt-4 text-xl font-semibold">Сообщение отправлено!</h2>
          <p className="mt-2 text-sm text-muted-foreground">Учитель получил ваше сообщение и ответит вам лично.</p>
          <Button variant="outline" className="mt-5 min-h-11" onClick={() => setSent(false)}>
            Написать ещё
          </Button>
        </div>
      ) : (
        <form
          className="flex flex-col gap-4 rounded-3xl border bg-card p-6 sm:p-8"
          onSubmit={(e) => {
            e.preventDefault();
            setError(null);
            submitMutation.mutate({ category, message: message.trim() });
          }}
        >
          <div role="group" aria-label="Тип сообщения" className="flex flex-wrap gap-1.5 rounded-xl border bg-background p-1">
            {CATEGORIES.map((c) => (
              <button
                type="button"
                key={c.value}
                onClick={() => setCategory(c.value)}
                aria-pressed={category === c.value}
                className={`flex min-h-10 flex-1 items-center justify-center gap-1.5 rounded-lg px-3 text-sm font-bold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
                  category === c.value ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-accent"
                }`}
              >
                <c.icon className="h-4 w-4" aria-hidden /> {c.label}
              </button>
            ))}
          </div>
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={6}
            required
            minLength={3}
            maxLength={3000}
            placeholder="Например: не понял тему «Теорема Виета», можно больше примеров? Или: было бы удобно, если бы…"
            className="w-full rounded-xl border bg-background px-4 py-3 text-base leading-relaxed focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            aria-label="Текст сообщения"
          />
          {error && (
            <p role="alert" className="rounded-xl border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm font-semibold text-destructive">
              {error}
            </p>
          )}
          <Button type="submit" className="min-h-12 gap-2" disabled={message.trim().length < 3 || submitMutation.isPending}>
            {submitMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Send className="h-4 w-4" aria-hidden />}
            Отправить учителю
          </Button>
        </form>
      )}
    </div>
  );
}
