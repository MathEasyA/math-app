import { Link, useParams, useSearchParams } from "react-router";
import { ArrowLeft, BookOpen, CheckCircle2, PenLine } from "lucide-react";
import { useState } from "react";

import { findExam } from "@contracts/content";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import NotFound from "./NotFound";
import { TheoryBlockView } from "./TopicPage";

export default function ExamPage() {
  const { examId } = useParams<{ examId: string }>();
  const exam = findExam(examId ?? "");
  const [searchParams, setSearchParams] = useSearchParams();
  const tab = searchParams.get("tab") === "practice" ? "practice" : "theory";

  if (!exam) return <NotFound />;

  return (
    <div className="flex flex-col gap-6">
      <div>
        <Link to="/exams" className="mb-4 inline-flex min-h-11 items-center gap-2 text-sm font-semibold text-muted-foreground transition-colors hover:text-foreground">
          <ArrowLeft className="h-4 w-4" aria-hidden /> Все экзамены
        </Link>
        <h1 className="font-display text-3xl font-semibold">{exam.title} по математике</h1>
        <p className="mt-2 max-w-2xl text-muted-foreground">{exam.description}</p>
        <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
          {exam.facts.map((f) => (
            <div key={f.label} className="rounded-xl border bg-card px-3 py-2 text-center">
              <p className="font-display text-lg font-semibold">{f.value}</p>
              <p className="text-[11px] text-muted-foreground">{f.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Вкладки */}
      <div role="tablist" aria-label="Разделы экзамена" className="flex gap-2 rounded-2xl border bg-card p-1.5">
        {(
          [
            { id: "theory", label: "Теория", icon: <BookOpen className="h-4 w-4" aria-hidden /> },
            { id: "practice", label: "Практика", icon: <PenLine className="h-4 w-4" aria-hidden /> },
          ] as const
        ).map((t) => (
          <button
            key={t.id}
            role="tab"
            aria-selected={tab === t.id}
            onClick={() => setSearchParams({ tab: t.id })}
            className={`flex min-h-11 flex-1 items-center justify-center gap-2 rounded-xl px-4 py-2 text-sm font-bold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
              tab === t.id ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-accent"
            }`}
          >
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      {tab === "theory" ? <ExamTheory examId={exam.id} /> : <ExamPractice examId={exam.id} />}
    </div>
  );
}

function ExamTheory({ examId }: { examId: "oge" | "ege" }) {
  const exam = findExam(examId)!;
  const [openId, setOpenId] = useState<string | null>(exam.theoryTopics[0]?.id ?? null);

  return (
    <div className="flex flex-col gap-3">
      {exam.theoryTopics.map((topic, i) => {
        const open = openId === topic.id;
        return (
          <div key={topic.id} className="rounded-2xl border bg-card">
            <button
              onClick={() => setOpenId(open ? null : topic.id)}
              aria-expanded={open}
              className="flex w-full items-center gap-3 px-4 py-4 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-ring sm:px-5"
            >
              <span className="font-display text-2xl font-semibold text-primary/30">{String(i + 1).padStart(2, "0")}</span>
              <span className="flex-1">
                <span className="block text-base font-bold">{topic.title}</span>
                <span className="block text-sm text-muted-foreground">{topic.description}</span>
              </span>
              <span className={`text-xl text-muted-foreground transition-transform duration-200 ${open ? "rotate-45" : ""}`} aria-hidden>
                +
              </span>
            </button>
            {open && (
              <div className="flex flex-col gap-4 border-t px-5 py-5 sm:px-6">
                {topic.theory.map((block, bi) => (
                  <TheoryBlockView key={bi} block={block} />
                ))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

function ExamPractice({ examId }: { examId: "oge" | "ege" }) {
  const exam = findExam(examId)!;
  const { isAuthenticated } = useAuth();
  const progressQuery = trpc.tasks.progress.useQuery(undefined, { enabled: isAuthenticated });
  const topicProgress = new Map(
    (progressQuery.data ?? []).filter((r) => r.sectionId === exam.id).map((r) => [r.topicId, r]),
  );

  return (
    <div className="flex flex-col gap-3">
      <p className="text-sm text-muted-foreground">
        Выбери тип задания — ИИ сгенерирует новую задачу в формате {exam.title}. Задания бесконечны.
      </p>
      {exam.practiceTopics.map((topic) => {
        const p = topicProgress.get(topic.id);
        return (
          <Link
            key={topic.id}
            to={`/practice/${exam.id}/${topic.id}`}
            className="topic-row"
          >
            <span className="min-w-0 flex-1">
              <span className="block text-base font-bold">{topic.title}</span>
              <span className="block text-sm text-muted-foreground">{topic.description}</span>
              {p && (
                <span className="mt-1 inline-flex items-center gap-1.5 text-xs font-semibold text-success">
                  <CheckCircle2 className="h-3.5 w-3.5" aria-hidden />
                  Решено: {p.total}, верно: {p.correct}
                </span>
              )}
            </span>
            <Badge variant="secondary" className="shrink-0">∞ задач</Badge>
          </Link>
        );
      })}
    </div>
  );
}
