import { useState } from "react";
import { Link, useParams } from "react-router";
import {
  ArrowLeft,
  CheckCircle2,
  ClipboardList,
  Loader2,
  Lock,
  Send,
} from "lucide-react";

import { MathText } from "@/components/MathText";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import NotFound from "./NotFound";

type Phase =
  | { kind: "intro" }
  | { kind: "loading" }
  | { kind: "run"; title: string; questions: { taskId: number; question: string }[] }
  | { kind: "done"; correct: number; total: number };

/**
 * Контрольная работа (режим обучения).
 * Задания общие для всех, решения и правильные ответы НЕ показываются.
 * Пока работа не сдана — доступ к темам закрыт.
 */
export default function ExamWorkPage() {
  const { workId: workIdParam } = useParams<{ workId: string }>();
  const workId = Number(workIdParam);
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const utils = trpc.useUtils();

  const myWorksQuery = trpc.examWork.myWorks.useQuery(undefined, { enabled: isAuthenticated });
  const [phase, setPhase] = useState<Phase>({ kind: "intro" });
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const startMutation = trpc.examWork.start.useMutation({
    onSuccess: (data) => {
      setAnswers({});
      setErrorMsg(null);
      setPhase({ kind: "run", title: data.title, questions: data.questions });
      utils.examWork.myWorks.invalidate();
    },
    onError: (err) => {
      setErrorMsg(err.message);
      setPhase({ kind: "intro" });
    },
  });

  const submitMutation = trpc.examWork.submit.useMutation({
    onSuccess: (data) => {
      setPhase({ kind: "done", correct: data.correct, total: data.total });
      utils.examWork.myWorks.invalidate();
      utils.learning.topicGate.invalidate();
    },
    onError: (err) => setErrorMsg(err.message),
  });

  if (!Number.isInteger(workId) || workId <= 0) return <NotFound />;

  const work = (myWorksQuery.data?.works ?? []).find((w) => w.id === workId);
  const workNotFound = myWorksQuery.data && !work && phase.kind === "intro";

  const start = () => {
    setErrorMsg(null);
    setPhase({ kind: "loading" });
    startMutation.mutate({ workId });
  };

  /* ---------- Нет такой контрольной ---------- */
  if (workNotFound) {
    return (
      <div className="flex max-w-2xl flex-col gap-6">
        <section className="rounded-3xl border bg-card p-8 text-center sm:p-12">
          <Lock className="mx-auto h-10 w-10 text-muted-foreground" aria-hidden />
          <h1 className="font-display mt-4 text-2xl font-semibold">Контрольная не найдена</h1>
          <p className="mx-auto mt-2 max-w-md text-muted-foreground">
            Возможно, она уже закрыта учителем или предназначена другому классу.
          </p>
          <Link
            to="/"
            className="mt-6 inline-flex min-h-11 items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground transition-transform duration-200 hover:scale-[1.02] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <ArrowLeft className="h-4 w-4" aria-hidden /> На главную
          </Link>
        </section>
      </div>
    );
  }

  /* ---------- Вступление ---------- */
  if (phase.kind === "intro") {
    const alreadyDone = work?.myStatus === "done";
    return (
      <div className="flex max-w-2xl flex-col gap-6">
        <section className="rounded-3xl border-2 border-primary/30 bg-primary/5 p-6 sm:p-10">
          <ClipboardList className="h-10 w-10 text-primary" aria-hidden />
          <h1 className="font-display mt-4 text-2xl font-semibold sm:text-3xl">
            {work?.title ?? "Контрольная работа"}
          </h1>
          <p className="mt-2 text-muted-foreground">
            {work ? `${work.taskCount} заданий · ${work.grade} класс` : ""}
          </p>
          <ul className="mx-auto mt-5 flex max-w-md flex-col gap-2 rounded-2xl bg-card p-5 text-left text-sm">
            <li className="flex gap-2"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-success" aria-hidden /> Ответы — числа или дроби, без вариантов решений</li>
            <li className="flex gap-2"><Lock className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden /> На время контрольной доступ ко всем темам закрывается — чтобы никто не подглядывал</li>
            <li className="flex gap-2"><Send className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden /> После сдачи решения и правильные ответы не показываются — результат отправляется учителю</li>
          </ul>
          {alreadyDone && work?.myScore ? (
            <>
              <p className="font-display mt-6 text-xl font-semibold">Работа сдана: {work.myScore.correct} из {work.myScore.total}</p>
              <p className="mt-1 text-sm text-muted-foreground">Решения и правильные ответы не показываются.</p>
            </>
          ) : (
            <Button
              className="mt-6 min-h-12 gap-2 px-8"
              onClick={start}
              disabled={startMutation.isPending || authLoading || !isAuthenticated}
            >
              {startMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : null}
              {work?.myStatus === "in_progress" ? "Продолжить контрольную" : "Начать контрольную"}
            </Button>
          )}
          {!authLoading && !isAuthenticated && (
            <p className="mt-3 text-sm text-muted-foreground">Войдите, чтобы написать контрольную.</p>
          )}
          {errorMsg && <p role="alert" className="mt-4 text-sm font-semibold text-destructive">{errorMsg}</p>}
        </section>
      </div>
    );
  }

  /* ---------- Загрузка заданий ---------- */
  if (phase.kind === "loading") {
    return (
      <section className="flex flex-col items-center gap-4 rounded-3xl border bg-card p-10 text-center" aria-live="polite">
        <Loader2 className="h-8 w-8 animate-spin text-primary" aria-hidden />
        <p className="font-semibold">Открываем контрольную…</p>
      </section>
    );
  }

  /* ---------- Сдано ---------- */
  if (phase.kind === "done") {
    return (
      <div className="flex max-w-2xl flex-col gap-6">
        <section className="rounded-3xl border-2 border-success/40 bg-success/5 p-6 text-center sm:p-10" aria-live="polite">
          <CheckCircle2 className="mx-auto h-12 w-12 text-success" aria-hidden />
          <h1 className="font-display mt-4 text-2xl font-semibold sm:text-3xl">Работа сдана!</h1>
          <p className="font-display mt-3 text-4xl font-semibold">{phase.correct} из {phase.total}</p>
          <p className="mt-1 text-sm text-muted-foreground">верных ответов</p>
          <p className="mx-auto mt-4 max-w-md text-muted-foreground">
            Результат отправлен учителю. Решения и правильные ответы не показываются.
            Доступ к темам снова открыт.
          </p>
          <Link
            to="/"
            className="mt-6 inline-flex min-h-12 items-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-bold text-primary-foreground transition-transform duration-200 hover:scale-[1.02] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            К обучению
          </Link>
        </section>
      </div>
    );
  }

  /* ---------- Прохождение ---------- */
  const allAnswered = phase.questions.every((q) => (answers[q.taskId] ?? "").trim().length > 0);
  return (
    <div className="flex max-w-3xl flex-col gap-5">
      <div className="rounded-3xl border bg-card p-6 sm:p-8">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h1 className="font-display text-2xl font-semibold">{phase.title}</h1>
          <p className="inline-flex items-center gap-1.5 rounded-full bg-destructive/10 px-3 py-1 text-xs font-bold text-destructive">
            <Lock className="h-3 w-3" aria-hidden /> темы закрыты до сдачи
          </p>
        </div>
        <p className="mt-1 text-sm text-muted-foreground">
          Ответьте на все {phase.questions.length} заданий. Решения и правильные ответы не показываются.
        </p>
      </div>
      <ol className="flex flex-col gap-5">
        {phase.questions.map((q, i) => (
          <li key={q.taskId} className="rounded-2xl border bg-card p-4 sm:p-5">
            <p className="mb-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">Задание {i + 1}</p>
            <div className="leading-relaxed"><MathText text={q.question} /></div>
            <input
              value={answers[q.taskId] ?? ""}
              onChange={(e) => setAnswers((a) => ({ ...a, [q.taskId]: e.target.value }))}
              placeholder="Ваш ответ"
              autoComplete="off"
              className="mt-3 min-h-11 w-full max-w-xs rounded-xl border bg-background px-4 text-base focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              aria-label={`Ответ на задание ${i + 1}`}
            />
          </li>
        ))}
      </ol>
      <Button
        className="min-h-12 gap-2 self-start px-6"
        disabled={!allAnswered || submitMutation.isPending}
        onClick={() =>
          submitMutation.mutate({
            workId,
            answers: phase.questions.map((q) => ({ taskId: q.taskId, answer: (answers[q.taskId] ?? "").trim() })),
          })
        }
      >
        {submitMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Send className="h-4 w-4" aria-hidden />}
        Сдать контрольную
      </Button>
      {!allAnswered && <p className="text-xs text-muted-foreground">Ответьте на все задания, чтобы сдать работу.</p>}
      {errorMsg && <p role="alert" className="text-sm font-semibold text-destructive">{errorMsg}</p>}
    </div>
  );
}
