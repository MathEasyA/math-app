import { useMemo, useState } from "react";
import { useNavigate } from "react-router";
import { CalendarDays, ChevronDown, ChevronUp, Loader2, Lock, Search, UserRound, UsersRound } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { findPracticeTarget } from "@contracts/content";
import type { inferRouterOutputs } from "@trpc/server";
import type { AppRouter } from "../../api/router";

type UserRow = inferRouterOutputs<AppRouter>["teacher"]["usersWithProgress"][number];

function fmtDate(d: Date | string | null | undefined): string {
  if (!d) return "—";
  return new Date(d).toLocaleDateString("ru-RU", { day: "numeric", month: "short", year: "numeric" });
}

export default function UsersPage() {
  const { user, isLoading } = useAuth();
  const navigate = useNavigate();

  if (!isLoading && user?.role !== "admin") {
    return (
      <div className="rounded-3xl border bg-card p-8 text-center">
        <Lock className="mx-auto h-10 w-10 text-primary" aria-hidden />
        <h1 className="font-display mt-4 text-xl font-semibold">Этот раздел доступен только учителю</h1>
        <Button className="mt-5 min-h-11" onClick={() => navigate("/")}>На главную</Button>
      </div>
    );
  }

  return <UsersList />;
}

function UsersList() {
  const listQuery = trpc.teacher.usersWithProgress.useQuery();
  const [filter, setFilter] = useState("");
  const [openId, setOpenId] = useState<number | null>(null);

  const users = useMemo(() => {
    const all = listQuery.data ?? [];
    const q = filter.trim().toLowerCase();
    if (!q) return all;
    return all.filter(
      (u) =>
        (u.name ?? "").toLowerCase().includes(q) ||
        (u.email ?? "").toLowerCase().includes(q),
    );
  }, [listQuery.data, filter]);

  if (listQuery.isLoading) {
    return (
      <div className="flex justify-center p-10">
        <Loader2 className="h-6 w-6 animate-spin text-primary" aria-hidden />
      </div>
    );
  }

  const total = listQuery.data?.length ?? 0;

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="font-display flex items-center gap-3 text-3xl font-semibold">
          <UsersRound className="h-7 w-7 text-primary" aria-hidden /> Пользователи
        </h1>
        <p className="mt-2 text-muted-foreground">
          Все, кто входил в приложение, и их прогресс по темам. Всего: {total}.
        </p>
      </div>

      {total > 0 && (
        <label className="relative block">
          <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
          <input
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            placeholder="Поиск по имени или почте…"
            className="min-h-12 w-full rounded-xl border bg-card pl-11 pr-4 text-base focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          />
        </label>
      )}

      {total === 0 ? (
        <div className="rounded-3xl border bg-card p-8 text-center">
          <p className="font-display text-xl font-semibold">Пока никого нет</p>
          <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
            Как только ученик войдёт в приложение через Kimi, он появится в этом списке.
          </p>
        </div>
      ) : users.length === 0 ? (
        <div className="rounded-3xl border bg-card p-8 text-center">
          <p className="text-muted-foreground">Никого не найдено по запросу «{filter}».</p>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {users.map((u) => (
            <UserCard
              key={u.id}
              u={u}
              open={openId === u.id}
              onToggle={() => setOpenId(openId === u.id ? null : u.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function UserCard({ u, open, onToggle }: { u: UserRow; open: boolean; onToggle: () => void }) {
  const active = u.accessUntil !== null && new Date(u.accessUntil).getTime() > Date.now();
  const pct = u.solved > 0 ? Math.round((u.correct / u.solved) * 100) : null;
  const initials = (u.name ?? "У").trim().charAt(0).toUpperCase();

  return (
    <div className="rounded-2xl border bg-card p-4 sm:p-5">
      <div className="flex items-start gap-3">
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-primary/10 text-base font-bold text-primary" aria-hidden>
          {initials}
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <p className="truncate font-bold">{u.name ?? "Без имени"}</p>
            {u.role === "admin" ? (
              <Badge variant="default">Учитель</Badge>
            ) : (
              <>
                <Badge variant={active ? "default" : "secondary"}>
                  {active ? `Доступ до ${fmtDate(u.accessUntil)}` : "Доступ закрыт"}
                </Badge>
                {u.trialGranted && <Badge variant="secondary">Пробный</Badge>}
                {u.grade != null && <Badge variant="secondary">{u.grade} класс</Badge>}
                {u.learningMode === "course" && <Badge variant="secondary">Обучение</Badge>}
                {u.learningMode === "free" && <Badge variant="secondary">Банк заданий</Badge>}
                {u.placementDone && u.placementTotal != null && u.placementTotal > 0 && (
                  <Badge variant="secondary">
                    Входной тест: {u.placementScore}/{u.placementTotal}
                  </Badge>
                )}
              </>
            )}
          </div>
          <p className="truncate text-sm text-muted-foreground">{u.email ?? "—"}</p>
          <p className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-muted-foreground">
            <span className="inline-flex items-center gap-1">
              <CalendarDays className="h-3.5 w-3.5" aria-hidden /> Регистрация: {fmtDate(u.createdAt)}
            </span>
            <span>Вход: {fmtDate(u.lastSignInAt)}</span>
            {u.lastAttemptAt && <span>Решал(а): {fmtDate(u.lastAttemptAt)}</span>}
          </p>
        </div>
      </div>

      {/* Итоги */}
      <div className="mt-4 grid grid-cols-3 gap-2">
        <div className="rounded-xl bg-accent/50 px-3 py-2 text-center">
          <p className="font-display text-xl font-semibold">{u.solved}</p>
          <p className="text-xs text-muted-foreground">решено</p>
        </div>
        <div className="rounded-xl bg-accent/50 px-3 py-2 text-center">
          <p className="font-display text-xl font-semibold">{u.correct}</p>
          <p className="text-xs text-muted-foreground">верно</p>
        </div>
        <div className="rounded-xl bg-accent/50 px-3 py-2 text-center">
          <p className="font-display text-xl font-semibold">{pct !== null ? `${pct}%` : "—"}</p>
          <p className="text-xs text-muted-foreground">точность</p>
        </div>
      </div>

      <Button variant="ghost" size="sm" className="mt-3 min-h-11 w-full justify-center" onClick={onToggle}>
        {open ? (
          <>
            <ChevronUp className="mr-1.5 h-4 w-4" aria-hidden /> Скрыть прогресс по темам
          </>
        ) : (
          <>
            <ChevronDown className="mr-1.5 h-4 w-4" aria-hidden /> Прогресс по темам ({u.topics.length})
          </>
        )}
      </Button>

      {open && <TopicBreakdown u={u} />}
    </div>
  );
}

function TopicBreakdown({ u }: { u: UserRow }) {
  if (u.topics.length === 0) {
    return (
      <p className="mt-2 flex items-center justify-center gap-2 rounded-xl border border-dashed px-4 py-5 text-sm text-muted-foreground">
        <UserRound className="h-4 w-4" aria-hidden /> Ещё не решал(а) ни одного задания
      </p>
    );
  }

  // Группируем по разделам, сохраняя порядок по свежести
  const sections: { sectionId: string; title: string; topics: UserRow["topics"] }[] = [];
  for (const t of u.topics) {
    let s = sections.find((x) => x.sectionId === t.sectionId);
    if (!s) {
      const target = findPracticeTarget(t.sectionId, t.topicId);
      s = { sectionId: t.sectionId, title: target?.sectionTitle ?? t.sectionId, topics: [] };
      sections.push(s);
    }
    s.topics.push(t);
  }

  return (
    <div className="mt-3 flex flex-col gap-4 border-t pt-4">
      {sections.map((s) => (
        <div key={s.sectionId}>
          <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">{s.title}</p>
          <div className="mt-2 flex flex-col gap-2">
            {s.topics.map((t) => {
              const target = findPracticeTarget(t.sectionId, t.topicId);
              const tpct = t.total > 0 ? Math.round((t.correct / t.total) * 100) : 0;
              return (
                <div key={`${t.sectionId}:${t.topicId}`} className="rounded-xl bg-accent/40 px-3.5 py-2.5">
                  <div className="flex items-baseline justify-between gap-3">
                    <p className="min-w-0 truncate text-sm font-semibold">{target?.topicTitle ?? t.topicId}</p>
                    <p className="shrink-0 text-xs text-muted-foreground">
                      {t.correct} из {t.total} · {tpct}%
                    </p>
                  </div>
                  <div
                    className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-muted"
                    role="progressbar"
                    aria-valuenow={tpct}
                    aria-valuemin={0}
                    aria-valuemax={100}
                    aria-label={`Точность по теме ${target?.topicTitle ?? t.topicId}`}
                  >
                    <div
                      className={`h-full rounded-full ${tpct >= 70 ? "bg-success" : tpct >= 40 ? "bg-primary" : "bg-destructive/70"}`}
                      style={{ width: `${tpct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}
