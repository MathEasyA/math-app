import { Link } from "react-router";
import { ArrowRight, Sparkles } from "lucide-react";

import { exams } from "@contracts/content";

export default function ExamsPage() {
  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="font-display text-3xl font-semibold">Экзамены</h1>
        <p className="mt-2 max-w-2xl text-muted-foreground">
          Два государственных экзамена по математике. Внутри каждого — теория по формату и типам заданий
          и бесконечная практика с генерацией задач ИИ.
        </p>
      </div>
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        {exams.map((e) => (
          <div key={e.id} className="flex flex-col rounded-3xl border-2 border-primary/25 bg-card p-6">
            <div className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-primary" aria-hidden />
              <h2 className="font-display text-2xl font-semibold">{e.title}</h2>
            </div>
            <p className="mt-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">{e.subtitle}</p>
            <p className="mt-3 text-sm text-muted-foreground">{e.description}</p>
            <div className="mt-4 grid grid-cols-2 gap-2">
              {e.facts.map((f) => (
                <div key={f.label} className="rounded-xl bg-muted px-3 py-2 text-center">
                  <p className="font-display text-lg font-semibold">{f.value}</p>
                  <p className="text-[11px] text-muted-foreground">{f.label}</p>
                </div>
              ))}
            </div>
            <div className="mt-5 flex flex-col gap-2 sm:flex-row">
              <Link
                to={`/exams/${e.id}?tab=theory`}
                className="inline-flex min-h-11 flex-1 items-center justify-center gap-2 rounded-xl border px-4 py-2 text-sm font-bold transition-colors hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                Теория
              </Link>
              <Link
                to={`/exams/${e.id}?tab=practice`}
                className="inline-flex min-h-11 flex-1 items-center justify-center gap-2 rounded-xl bg-primary px-4 py-2 text-sm font-bold text-primary-foreground transition-transform duration-200 hover:scale-[1.02] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                Практика <ArrowRight className="h-4 w-4" aria-hidden />
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
