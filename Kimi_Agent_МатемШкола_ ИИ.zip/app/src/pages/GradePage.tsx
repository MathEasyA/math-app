import { Link, useParams } from "react-router";
import { ArrowLeft, BookOpen, CheckCircle2, ClipboardCheck, Lock, PenLine } from "lucide-react";

import { findGrade } from "@contracts/content";
import { Badge } from "@/components/ui/badge";
import { ExamWorkBanner } from "@/components/ExamWorkBanner";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import NotFound from "./NotFound";

export default function GradePage() {
  const { grade: gradeParam } = useParams<{ grade: string }>();
  const grade = findGrade(Number(gradeParam));
  const { user, isAuthenticated } = useAuth();
  const progressQuery = trpc.tasks.progress.useQuery(undefined, { enabled: isAuthenticated });
  const statusesQuery = trpc.learning.topicStatuses.useQuery(undefined, { enabled: isAuthenticated });

  if (!grade) return <NotFound />;

  const sectionId = `grade-${grade.grade}`;
  const topicProgress = new Map(
    (progressQuery.data ?? [])
      .filter((r) => r.sectionId === sectionId)
      .map((r) => [r.topicId, r]),
  );

  const isAdmin = user?.role === "admin";
  // Режим обучения: цепочка теория → тест → практика и последовательное открытие тем
  const courseMode = isAuthenticated && !isAdmin && user?.learningMode === "course";
  const ownGrade = user?.grade === grade.grade;
  const theoryRead = new Set(statusesQuery.data?.theoryRead ?? []);
  const testPassed = new Set(statusesQuery.data?.testPassed ?? []);

  // Последовательность: тема открыта, если сданы тесты по всем предыдущим
  const topicOpen: boolean[] = [];
  if (courseMode) {
    let allPrevPassed = true;
    for (const t of grade.topics) {
      topicOpen.push(allPrevPassed);
      if (!testPassed.has(`${sectionId}:${t.id}`)) allPrevPassed = false;
    }
  }

  if (courseMode && !ownGrade) {
    return (
      <div className="flex flex-col gap-6">
        <Link to="/" className="inline-flex min-h-11 items-center gap-2 text-sm font-semibold text-muted-foreground transition-colors hover:text-foreground">
          <ArrowLeft className="h-4 w-4" aria-hidden /> На главную
        </Link>
        <section className="rounded-3xl border bg-card p-8 text-center sm:p-12">
          <Lock className="mx-auto h-10 w-10 text-muted-foreground" aria-hidden />
          <h1 className="font-display mt-4 text-2xl font-semibold">{grade.title} закрыт</h1>
          <p className="mx-auto mt-2 max-w-md text-muted-foreground">
            В режиме обучения открыт только ваш класс{user?.grade ? ` — ${user?.grade}` : ""}.
          </p>
          {user?.grade && (
            <Link
              to={`/class/${user.grade}`}
              className="mt-6 inline-flex min-h-11 items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground transition-transform duration-200 hover:scale-[1.02] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              Перейти к моему классу
            </Link>
          )}
        </section>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <ExamWorkBanner />
      <div>
        <Link to="/" className="mb-4 inline-flex min-h-11 items-center gap-2 text-sm font-semibold text-muted-foreground transition-colors hover:text-foreground">
          <ArrowLeft className="h-4 w-4" aria-hidden /> На главную
        </Link>
        <h1 className="font-display text-3xl font-semibold">{grade.title}</h1>
        <p className="mt-2 text-muted-foreground">{grade.description}</p>
        <div className="mt-3 flex flex-wrap gap-2">
          <Badge variant="secondary">{grade.topics.length} тем</Badge>
          <Badge variant="secondary">теория + ИИ-практика</Badge>
        </div>
        {courseMode && (
          <p className="mt-4 rounded-2xl bg-accent/50 px-4 py-3 text-sm text-muted-foreground">
            Темы открываются по порядку: <b className="text-foreground">теория</b> → <b className="text-foreground">проверочная работа</b> (ошибок не больше 20%) → <b className="text-foreground">практика с ИИ</b>. Новая тема откроется после сдачи проверочной по предыдущей.
          </p>
        )}
      </div>

      <ol className="flex flex-col gap-3">
        {grade.topics.map((topic, i) => {
          const p = topicProgress.get(topic.id);
          const key = `${sectionId}:${topic.id}`;
          const read = theoryRead.has(key);
          const passed = testPassed.has(key);
          const open = !courseMode || topicOpen[i];

          if (!open) {
            return (
              <li key={topic.id} className="rounded-2xl border bg-card/50 p-4 opacity-60 sm:p-5" aria-disabled>
                <div className="flex flex-wrap items-center gap-3">
                  <span className="font-display text-2xl font-semibold text-primary/20">{String(i + 1).padStart(2, "0")}</span>
                  <h2 className="text-base font-bold sm:text-lg">{topic.title}</h2>
                  <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground">
                    <Lock className="h-3.5 w-3.5" aria-hidden /> откроется после предыдущей темы
                  </span>
                </div>
                <p className="mt-1 text-sm text-muted-foreground sm:pl-11">{topic.description}</p>
              </li>
            );
          }

          return (
            <li key={topic.id} className="rounded-2xl border bg-card p-4 sm:p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-3">
                    <span className="font-display text-2xl font-semibold text-primary/30">{String(i + 1).padStart(2, "0")}</span>
                    <h2 className="text-base font-bold sm:text-lg">{topic.title}</h2>
                    {courseMode && read && (
                      <Badge variant="secondary" className="gap-1 text-success">
                        <CheckCircle2 className="h-3 w-3" aria-hidden /> теория
                      </Badge>
                    )}
                    {courseMode && passed && (
                      <Badge className="gap-1">
                        <CheckCircle2 className="h-3 w-3" aria-hidden /> проверочная сдана
                      </Badge>
                    )}
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground sm:pl-11">{topic.description}</p>
                  {p && p.total > 0 && (
                    <p className="mt-2 inline-flex items-center gap-1.5 text-xs font-semibold text-success sm:ml-11">
                      <CheckCircle2 className="h-3.5 w-3.5" aria-hidden />
                      Решено: {p.total}, верно: {p.correct}
                    </p>
                  )}
                </div>
              </div>
              <div className="mt-4 flex flex-col gap-2 sm:flex-row sm:pl-11">
                <Link
                  to={`/class/${grade.grade}/topic/${topic.id}`}
                  className="inline-flex min-h-11 flex-1 items-center justify-center gap-2 rounded-xl border bg-card px-4 py-2 text-sm font-bold transition-colors hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <BookOpen className="h-4 w-4" aria-hidden /> Теория
                </Link>
                {!courseMode ? (
                  <Link
                    to={`/practice/${sectionId}/${topic.id}`}
                    className="inline-flex min-h-11 flex-1 items-center justify-center gap-2 rounded-xl bg-primary px-4 py-2 text-sm font-bold text-primary-foreground transition-transform duration-200 hover:scale-[1.02] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <PenLine className="h-4 w-4" aria-hidden /> Практика
                  </Link>
                ) : passed ? (
                  <Link
                    to={`/practice/${sectionId}/${topic.id}`}
                    className="inline-flex min-h-11 flex-1 items-center justify-center gap-2 rounded-xl bg-primary px-4 py-2 text-sm font-bold text-primary-foreground transition-transform duration-200 hover:scale-[1.02] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <PenLine className="h-4 w-4" aria-hidden /> Практика
                  </Link>
                ) : read ? (
                  <Link
                    to={`/class/${grade.grade}/topic/${topic.id}#test`}
                    className="inline-flex min-h-11 flex-1 items-center justify-center gap-2 rounded-xl border-2 border-primary/40 bg-primary/5 px-4 py-2 text-sm font-bold text-primary transition-colors hover:bg-primary/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <ClipboardCheck className="h-4 w-4" aria-hidden /> Проверочная работа
                  </Link>
                ) : (
                  <span
                    className="inline-flex min-h-11 flex-1 cursor-not-allowed items-center justify-center gap-2 rounded-xl bg-muted px-4 py-2 text-sm font-bold text-muted-foreground"
                    title="Практика откроется после теории и теста"
                  >
                    <Lock className="h-4 w-4" aria-hidden /> Практика закрыта
                  </span>
                )}
              </div>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
