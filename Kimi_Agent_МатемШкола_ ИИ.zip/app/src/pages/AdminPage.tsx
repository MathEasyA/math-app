import { Link, useNavigate, useSearchParams } from "react-router";
import { ClipboardList, Inbox, Loader2, Lock, MailOpen, Plus, Send, Settings2, Users, UsersRound } from "lucide-react";
import { useEffect, useState } from "react";

import { findGrade, grades } from "@contracts/content";
import { MathText } from "@/components/MathText";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";

const CATEGORY_LABEL: Record<string, string> = {
  question: "Вопрос",
  suggestion: "Предложение",
  problem: "Проблема",
};

export default function AdminPage() {
  const { user, isLoading } = useAuth();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const tab = searchParams.get("tab") ?? "students";

  if (!isLoading && user?.role !== "admin") {
    return (
      <div className="rounded-3xl border bg-card p-8 text-center">
        <Lock className="mx-auto h-10 w-10 text-primary" aria-hidden />
        <h1 className="font-display mt-4 text-xl font-semibold">Этот раздел доступен только учителю</h1>
        <Button className="mt-5 min-h-11" onClick={() => navigate("/")}>На главную</Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="font-display text-3xl font-semibold">Кабинет учителя</h1>
        <p className="mt-2 text-muted-foreground">Ученики и доступ, входящие сообщения, настройки уведомлений.</p>
      </div>

      <div role="tablist" aria-label="Разделы кабинета" className="flex gap-2 rounded-2xl border bg-card p-1.5">
        {(
          [
            { id: "students", label: "Ученики", icon: <Users className="h-4 w-4" aria-hidden /> },
            { id: "works", label: "Контрольные", icon: <ClipboardList className="h-4 w-4" aria-hidden /> },
            { id: "inbox", label: "Входящие", icon: <Inbox className="h-4 w-4" aria-hidden /> },
            { id: "settings", label: "Настройки", icon: <Settings2 className="h-4 w-4" aria-hidden /> },
          ] as const
        ).map((t) => (
          <button
            key={t.id}
            role="tab"
            aria-selected={tab === t.id}
            onClick={() => setSearchParams({ tab: t.id })}
            className={`flex min-h-11 flex-1 items-center justify-center gap-2 rounded-xl px-3 py-2 text-sm font-bold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
              tab === t.id ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-accent"
            }`}
          >
            {t.icon} <span className="hidden sm:inline">{t.label}</span>
          </button>
        ))}
      </div>

      {tab === "students" && <StudentsTab />}
      {tab === "works" && <ExamWorksTab />}
      {tab === "inbox" && <InboxTab />}
      {tab === "settings" && <SettingsTab />}
    </div>
  );
}

/* ---------------- Ученики ---------------- */

function StudentsTab() {
  const studentsQuery = trpc.teacher.students.useQuery();
  const extraQuery = trpc.learning.studentExtra.useQuery();
  const utils = trpc.useUtils();
  const setAccess = trpc.teacher.setAccess.useMutation({
    onSuccess: () => utils.teacher.students.invalidate(),
  });
  const [pendingId, setPendingId] = useState<number | null>(null);

  const grant = (userId: number, days: number) => {
    setPendingId(userId);
    setAccess.mutate({ userId, days }, { onSettled: () => setPendingId(null) });
  };

  if (studentsQuery.isLoading) {
    return <div className="flex justify-center p-10"><Loader2 className="h-6 w-6 animate-spin text-primary" aria-hidden /></div>;
  }
  const students = studentsQuery.data ?? [];
  const extra = new Map((extraQuery.data ?? []).map((e) => [e.id, e]));

  if (students.length === 0) {
    return (
      <div className="rounded-3xl border bg-card p-8 text-center">
        <p className="font-display text-xl font-semibold">Пока нет учеников</p>
        <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
          Как только ученик войдёт в приложение через Kimi, он появится в этом списке — и вы сможете открыть ему доступ.
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-3">
      <Link
        to="/users"
        className="flex min-h-11 items-center justify-center gap-2 rounded-2xl border border-dashed bg-accent/30 px-4 text-sm font-semibold text-primary transition-colors hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        <UsersRound className="h-4 w-4" aria-hidden /> Все пользователи и подробный прогресс по темам →
      </Link>
      {students.map((s) => {
        const active = s.accessUntil !== null && new Date(s.accessUntil).getTime() > Date.now();
        const pct = s.solved > 0 ? Math.round((s.correct / s.solved) * 100) : null;
        const ex = extra.get(s.id);
        return (
          <div key={s.id} className="rounded-2xl border bg-card p-4 sm:p-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="truncate font-bold">{s.name ?? "Без имени"}</p>
                  {ex?.grade && <Badge variant="secondary">{ex.grade} класс</Badge>}
                  {ex?.learningMode === "course" && <Badge variant="secondary">Обучение</Badge>}
                  {ex?.learningMode === "free" && <Badge variant="secondary">Банк заданий</Badge>}
                </div>
                <p className="truncate text-sm text-muted-foreground">{s.email ?? "—"}</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {ex?.learningMode === "free"
                    ? "Свободный режим: входной тест не нужен"
                    : ex?.placementDone
                      ? `Входной тест: ${ex.placementScore}/${ex.placementTotal}`
                      : "Входной тест не пройден"}
                  {ex && ex.topicTestsTotal > 0 && ` · Тестов по темам сдано: ${ex.topicTestsPassed} из ${ex.topicTestsTotal}`}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {s.solved > 0
                    ? `Решено: ${s.solved}, верно: ${s.correct}${pct !== null ? ` (${pct}%)` : ""}`
                    : "Ещё ничего не решал"}
                  {" · "}Был(а): {new Date(s.lastSignInAt).toLocaleDateString("ru-RU")}
                </p>
              </div>
              <Badge variant={active ? "default" : "secondary"} className="shrink-0">
                {active
                  ? `Доступ до ${new Date(s.accessUntil!).toLocaleDateString("ru-RU")}`
                  : "Доступ закрыт"}
              </Badge>
              {s.trialGranted && <Badge variant="secondary" className="shrink-0">Пробный</Badge>}
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              {[30, 90, 365].map((d) => (
                <Button
                  key={d}
                  size="sm"
                  variant="outline"
                  className="min-h-11"
                  disabled={pendingId === s.id}
                  onClick={() => grant(s.id, d)}
                >
                  + {d === 365 ? "год" : `${d} дн.`}
                </Button>
              ))}
              {active && (
                <Button
                  size="sm"
                  variant="destructive"
                  className="min-h-11"
                  disabled={pendingId === s.id}
                  onClick={() => grant(s.id, 0)}
                >
                  Закрыть доступ
                </Button>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

/* ---------------- Контрольные работы ---------------- */

function ExamWorksTab() {
  const utils = trpc.useUtils();
  const listQuery = trpc.examWork.list.useQuery();
  const setStatus = trpc.examWork.setStatus.useMutation({
    onSuccess: () => utils.examWork.list.invalidate(),
  });
  const [creating, setCreating] = useState(false);
  const [resultsFor, setResultsFor] = useState<number | null>(null);

  if (listQuery.isLoading) {
    return <div className="flex justify-center p-10"><Loader2 className="h-6 w-6 animate-spin text-primary" aria-hidden /></div>;
  }
  const works = listQuery.data ?? [];

  return (
    <div className="flex flex-col gap-4">
      {!creating ? (
        <Button variant="outline" className="min-h-11 gap-2 self-start" onClick={() => setCreating(true)}>
          <Plus className="h-4 w-4" aria-hidden /> Новая контрольная
        </Button>
      ) : (
        <CreateExamWorkForm
          onDone={() => {
            setCreating(false);
            utils.examWork.list.invalidate();
          }}
          onCancel={() => setCreating(false)}
        />
      )}

      {works.length === 0 && !creating && (
        <div className="rounded-3xl border bg-card p-8 text-center">
          <p className="font-display text-xl font-semibold">Контрольных пока нет</p>
          <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
            Создайте контрольную: задания сгенерирует ИИ один раз для всех учеников класса.
            На время прохождения у ученика закрывается доступ ко всем темам, а решения не показываются.
          </p>
        </div>
      )}

      {works.map((w) => {
        const gradeTitle = findGrade(w.grade)?.title ?? `${w.grade} класс`;
        return (
          <div key={w.id} className="rounded-2xl border bg-card p-4 sm:p-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="font-bold">{w.title}</p>
                  <Badge variant="secondary">{gradeTitle}</Badge>
                  <Badge variant={w.status === "active" ? "default" : "secondary"}>
                    {w.status === "active" ? "Открыта" : "Закрыта"}
                  </Badge>
                </div>
                <p className="mt-1 text-xs text-muted-foreground">
                  Заданий: {w.taskCount} · прохождений: {w.attemptCount} · темы:{" "}
                  {(w.topicIds as string[])
                    .map((id) => findGrade(w.grade)?.topics.find((t) => t.id === id)?.title ?? id)
                    .join(", ")}
                </p>
              </div>
              <div className="flex flex-wrap gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  className="min-h-11"
                  onClick={() => setResultsFor(resultsFor === w.id ? null : w.id)}
                >
                  {resultsFor === w.id ? "Скрыть результаты" : "Результаты"}
                </Button>
                <Button
                  size="sm"
                  variant={w.status === "active" ? "destructive" : "default"}
                  className="min-h-11"
                  disabled={setStatus.isPending}
                  onClick={() => setStatus.mutate({ workId: w.id, status: w.status === "active" ? "closed" : "active" })}
                >
                  {w.status === "active" ? "Закрыть" : "Открыть снова"}
                </Button>
              </div>
            </div>
            {resultsFor === w.id && <ExamWorkResults workId={w.id} />}
          </div>
        );
      })}
    </div>
  );
}

function CreateExamWorkForm({ onDone, onCancel }: { onDone: () => void; onCancel: () => void }) {
  const [title, setTitle] = useState("");
  const [grade, setGrade] = useState(8);
  const [selected, setSelected] = useState<string[]>([]);
  const [tasksPerTopic, setTasksPerTopic] = useState(1);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const createMutation = trpc.examWork.create.useMutation({
    onSuccess: () => onDone(),
    onError: (err) => setErrorMsg(err.message),
  });

  const gradeData = findGrade(grade);
  const topics = gradeData?.topics ?? [];

  const toggle = (id: string) =>
    setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));

  return (
    <form
      className="flex flex-col gap-4 rounded-2xl border-2 border-primary/30 bg-primary/5 p-5"
      onSubmit={(e) => {
        e.preventDefault();
        setErrorMsg(null);
        createMutation.mutate({ title: title.trim(), grade, topicIds: selected, tasksPerTopic });
      }}
    >
      <h2 className="font-display text-lg font-semibold">Новая контрольная работа</h2>
      <label className="flex flex-col gap-1.5">
        <span className="text-sm font-bold">Название</span>
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Например: Контрольная по квадратным уравнениям"
          required
          maxLength={200}
          className="min-h-12 rounded-xl border bg-background px-4 text-base focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        />
      </label>
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-sm font-bold">Класс:</span>
        {grades.map((g) => (
          <button
            key={g.grade}
            type="button"
            onClick={() => { setGrade(g.grade); setSelected([]); }}
            aria-pressed={grade === g.grade}
            className={`min-h-10 rounded-xl border px-4 text-sm font-bold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
              grade === g.grade ? "bg-primary text-primary-foreground" : "bg-card hover:bg-accent"
            }`}
          >
            {g.grade}
          </button>
        ))}
      </div>
      <fieldset>
        <legend className="text-sm font-bold">Темы контрольной (выберите хотя бы одну)</legend>
        <div className="mt-2 grid gap-2 sm:grid-cols-2">
          {topics.map((t) => (
            <label
              key={t.id}
              className={`flex min-h-11 cursor-pointer items-center gap-2 rounded-xl border px-3 py-2 text-sm transition-colors ${
                selected.includes(t.id) ? "border-primary bg-primary/10 font-semibold" : "bg-card hover:bg-accent"
              }`}
            >
              <input
                type="checkbox"
                checked={selected.includes(t.id)}
                onChange={() => toggle(t.id)}
                className="h-4 w-4 accent-primary"
              />
              {t.title}
            </label>
          ))}
        </div>
      </fieldset>
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-sm font-bold">Заданий по каждой теме:</span>
        {[1, 2, 3].map((n) => (
          <button
            key={n}
            type="button"
            onClick={() => setTasksPerTopic(n)}
            aria-pressed={tasksPerTopic === n}
            className={`min-h-10 rounded-xl border px-4 text-sm font-bold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
              tasksPerTopic === n ? "bg-primary text-primary-foreground" : "bg-card hover:bg-accent"
            }`}
          >
            {n}
          </button>
        ))}
        <span className="text-xs text-muted-foreground">· итого {selected.length * tasksPerTopic} заданий</span>
      </div>
      <div className="flex flex-wrap gap-2">
        <Button
          type="submit"
          className="min-h-11"
          disabled={!title.trim() || selected.length === 0 || createMutation.isPending}
        >
          {createMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden /> : null}
          {createMutation.isPending ? "ИИ составляет задания…" : "Создать контрольную"}
        </Button>
        <Button type="button" variant="ghost" className="min-h-11" onClick={onCancel} disabled={createMutation.isPending}>
          Отмена
        </Button>
      </div>
      {createMutation.isPending && (
        <p className="text-xs text-muted-foreground">Генерация займёт 20–60 секунд — задания создаются один раз для всех учеников.</p>
      )}
      {errorMsg && <p role="alert" className="text-sm font-semibold text-destructive">{errorMsg}</p>}
    </form>
  );
}

function ExamWorkResults({ workId }: { workId: number }) {
  const resultsQuery = trpc.examWork.results.useQuery({ workId });
  if (resultsQuery.isLoading) {
    return <div className="flex justify-center p-6"><Loader2 className="h-5 w-5 animate-spin text-primary" aria-hidden /></div>;
  }
  const data = resultsQuery.data;
  if (!data) return null;
  const taskById = new Map(data.tasks.map((t) => [t.id, t]));

  return (
    <div className="mt-4 flex flex-col gap-3 border-t pt-4">
      {data.attempts.length === 0 && (
        <p className="text-sm text-muted-foreground">Пока никто не начинал эту контрольную.</p>
      )}
      {data.attempts.map((a) => (
        <div key={a.id} className="rounded-xl bg-accent/40 p-4">
          <div className="flex flex-wrap items-center gap-2">
            <p className="text-sm font-bold">{a.userName ?? `Ученик #${a.userId}`}</p>
            {a.finishedAt != null ? (
              <Badge variant={a.correct !== null && a.total !== null && a.correct / a.total >= 0.7 ? "default" : "secondary"}>
                {a.correct} из {a.total}
              </Badge>
            ) : (
              <Badge variant="secondary">пишет сейчас</Badge>
            )}
            <span className="ml-auto text-xs text-muted-foreground">
              {new Date(a.startedAt).toLocaleString("ru-RU", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}
            </span>
          </div>
          {a.finishedAt != null && a.details && (
            <details className="mt-3">
              <summary className="min-h-11 cursor-pointer text-xs font-bold text-muted-foreground">Разбор ответов</summary>
              <ol className="mt-2 flex flex-col gap-2">
                {(a.details as { taskId: number; given: string; correct: boolean }[]).map((d, i) => {
                  const task = taskById.get(d.taskId);
                  return (
                    <li key={d.taskId} className="rounded-lg bg-card p-3 text-xs">
                      <div className="flex items-start gap-2">
                        <span className={`font-bold ${d.correct ? "text-success" : "text-destructive"}`}>
                          {i + 1}. {d.correct ? "✓" : "✗"}
                        </span>
                        <div className="min-w-0 flex-1">
                          {task && <MathText text={task.question} />}
                          <p className="mt-1 text-muted-foreground">
                            Ответ ученика: <b className={d.correct ? "text-success" : "text-destructive"}>{d.given}</b>
                            {task && !d.correct && <> · верно: <b className="text-foreground"><MathText text={`$${task.answer}$`} /></b></>}
                          </p>
                        </div>
                      </div>
                    </li>
                  );
                })}
              </ol>
            </details>
          )}
        </div>
      ))}
    </div>
  );
}

/* ---------------- Входящие ---------------- */

function InboxTab() {
  const listQuery = trpc.teacher.feedbackList.useQuery();
  const utils = trpc.useUtils();
  const markRead = trpc.teacher.markFeedbackRead.useMutation({
    onSuccess: () => {
      utils.teacher.feedbackList.invalidate();
      utils.teacher.unreadFeedbackCount.invalidate();
    },
  });
  const markAll = trpc.teacher.markAllFeedbackRead.useMutation({
    onSuccess: () => {
      utils.teacher.feedbackList.invalidate();
      utils.teacher.unreadFeedbackCount.invalidate();
    },
  });

  if (listQuery.isLoading) {
    return <div className="flex justify-center p-10"><Loader2 className="h-6 w-6 animate-spin text-primary" aria-hidden /></div>;
  }
  const items = listQuery.data ?? [];

  return (
    <div className="flex flex-col gap-3">
      {items.some((i) => !i.read) && (
        <Button variant="outline" className="min-h-11 self-start" onClick={() => markAll.mutate()} disabled={markAll.isPending}>
          <MailOpen className="mr-2 h-4 w-4" aria-hidden /> Отметить все прочитанными
        </Button>
      )}
      {items.length === 0 && (
        <div className="rounded-3xl border bg-card p-8 text-center">
          <p className="font-display text-xl font-semibold">Входящих пока нет</p>
          <p className="mt-2 text-sm text-muted-foreground">Здесь появятся вопросы и предложения учеников.</p>
        </div>
      )}
      {items.map((item) => (
        <div
          key={item.id}
          className={`rounded-2xl border p-4 sm:p-5 ${item.read ? "bg-card" : "border-primary/40 bg-accent/40"}`}
        >
          <div className="flex flex-wrap items-center gap-2">
            <Badge variant="secondary">{CATEGORY_LABEL[item.category] ?? item.category}</Badge>
            {!item.read && <Badge>Новое</Badge>}
            <span className="text-sm font-bold">{item.userName ?? "Без имени"}</span>
            <span className="text-xs text-muted-foreground">{item.userEmail ?? ""}</span>
            <span className="ml-auto text-xs text-muted-foreground">
              {new Date(item.createdAt).toLocaleString("ru-RU", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}
            </span>
          </div>
          <p className="mt-3 whitespace-pre-line text-sm leading-relaxed">{item.message}</p>
          {!item.read && (
            <Button
              variant="ghost"
              size="sm"
              className="mt-3 min-h-11"
              onClick={() => markRead.mutate({ id: item.id })}
              disabled={markRead.isPending}
            >
              Отметить прочитанным
            </Button>
          )}
        </div>
      ))}
    </div>
  );
}

/* ---------------- Настройки ---------------- */

function SettingsTab() {
  const settingsQuery = trpc.teacher.getSettings.useQuery();
  const utils = trpc.useUtils();
  const [form, setForm] = useState({ telegramBotToken: "", telegramChatId: "", priceText: "", contactText: "" });
  const [saved, setSaved] = useState(false);
  const [testMsg, setTestMsg] = useState<{ ok: boolean; text: string } | null>(null);

  useEffect(() => {
    if (settingsQuery.data) setForm(settingsQuery.data);
  }, [settingsQuery.data]);

  const updateMutation = trpc.teacher.updateSettings.useMutation({
    onSuccess: async () => {
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
      await utils.teacher.getSettings.invalidate();
      await utils.teacher.publicInfo.invalidate();
    },
  });

  const testMutation = trpc.teacher.testTelegram.useMutation({
    onSuccess: () => setTestMsg({ ok: true, text: "Тестовое сообщение отправлено! Проверьте Telegram." }),
    onError: (err) => setTestMsg({ ok: false, text: err.message }),
  });

  const set = (key: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm((f) => ({ ...f, [key]: e.target.value }));

  return (
    <form
      className="flex flex-col gap-6"
      onSubmit={(e) => {
        e.preventDefault();
        setTestMsg(null);
        updateMutation.mutate(form);
      }}
    >
      {/* Telegram */}
      <section className="rounded-3xl border bg-card p-6 sm:p-8">
        <h2 className="font-display flex items-center gap-2 text-xl font-semibold">
          <Send className="h-5 w-5 text-primary" aria-hidden /> Уведомления в Telegram
        </h2>
        <ol className="mt-3 list-decimal space-y-1 pl-5 text-sm leading-relaxed text-muted-foreground">
          <li>Откройте Telegram и напишите боту <b>@BotFather</b> → команда <b>/newbot</b> → придумайте имя. Он выдаст токен.</li>
          <li>Напишите любое сообщение вашему новому боту, затем откройте бота <b>@userinfobot</b> — он покажет ваш Chat ID.</li>
          <li>Вставьте токен и Chat ID ниже и нажмите «Сохранить», затем «Проверить связь».</li>
        </ol>
        <div className="mt-4 flex flex-col gap-3">
          <label className="flex flex-col gap-1.5">
            <span className="text-sm font-bold">Токен бота</span>
            <input
              value={form.telegramBotToken}
              onChange={set("telegramBotToken")}
              placeholder="1234567890:AAE…"
              className="min-h-12 rounded-xl border bg-background px-4 text-base focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            />
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="text-sm font-bold">Ваш Chat ID</span>
            <input
              value={form.telegramChatId}
              onChange={set("telegramChatId")}
              placeholder="123456789"
              className="min-h-12 rounded-xl border bg-background px-4 text-base focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            />
          </label>
        </div>
        {testMsg && (
          <p role="status" className={`mt-3 rounded-xl px-4 py-3 text-sm font-semibold ${testMsg.ok ? "bg-success/10 text-success" : "bg-destructive/10 text-destructive"}`}>
            {testMsg.text}
          </p>
        )}
        <Button
          type="button"
          variant="outline"
          className="mt-4 min-h-11"
          disabled={testMutation.isPending || updateMutation.isPending}
          onClick={() => {
            setTestMsg(null);
            testMutation.mutate();
          }}
        >
          {testMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden /> : null}
          Проверить связь
        </Button>
        <p className="mt-3 text-xs text-muted-foreground">
          Сюда приходят: отчёты о пройденных блоках тем (каждые 5 заданий по теме) и сообщения обратной связи от учеников.
        </p>
      </section>

      {/* Цена и контакты */}
      <section className="rounded-3xl border bg-card p-6 sm:p-8">
        <h2 className="font-display text-xl font-semibold">Цена и контакты</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Этот текст увидят ученики на экране закрытого доступа. Оплата проходит напрямую (переводом) — вы просто открываете доступ на вкладке «Ученики».
        </p>
        <div className="mt-4 flex flex-col gap-3">
          <label className="flex flex-col gap-1.5">
            <span className="text-sm font-bold">Стоимость</span>
            <textarea
              value={form.priceText}
              onChange={set("priceText")}
              rows={3}
              placeholder={"Например:\nАбонемент на месяц — 3000 ₽\nБезлимит на год — 25 000 ₽"}
              className="rounded-xl border bg-background px-4 py-3 text-base leading-relaxed focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            />
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="text-sm font-bold">Как оплатить / контакты</span>
            <textarea
              value={form.contactText}
              onChange={set("contactText")}
              rows={3}
              placeholder={"Например:\nНапишите мне в Telegram: @ivan_math\nПеревод на карту: 2200 …"}
              className="rounded-xl border bg-background px-4 py-3 text-base leading-relaxed focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            />
          </label>
        </div>
      </section>

      <Button type="submit" className="min-h-12 self-start px-8" disabled={updateMutation.isPending}>
        {updateMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden /> : null}
        {saved ? "Сохранено ✓" : "Сохранить настройки"}
      </Button>
    </form>
  );
}
