import { Link } from "react-router";
import { Lock, MessageCircleQuestion } from "lucide-react";

import { trpc } from "@/providers/trpc";

/** Экран закрытого доступа: цена, контакты учителя, ссылка на обратную связь */
export function AccessLocked({ accessUntil }: { accessUntil?: Date | null }) {
  const infoQuery = trpc.teacher.publicInfo.useQuery();
  const accessQuery = trpc.teacher.myAccess.useQuery();
  const info = infoQuery.data;
  const expired = accessUntil !== null && accessUntil !== undefined;
  const trialExpired = accessQuery.data?.trialExpired ?? false;

  return (
    <div className="rounded-3xl border bg-card p-8 text-center">
      <Lock className="mx-auto h-10 w-10 text-primary" aria-hidden />
      <h2 className="font-display mt-4 text-2xl font-semibold">
        {trialExpired ? "Пробный период закончился" : expired ? "Срок доступа истёк" : "Закрытый раздел"}
      </h2>
      <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
        {trialExpired
          ? "Неделя бесплатного доступа прошла. Чтобы продолжить решать задания с ИИ, оформите доступ у учителя."
          : expired
            ? "Чтобы продолжить решать задания, продлите доступ у учителя."
            : "Практика с ИИ доступна ученикам после оплаты. Теория открыта для всех."}
      </p>
      {info?.priceText && (
        <div className="mx-auto mt-5 max-w-md rounded-2xl bg-accent/60 px-5 py-4 text-left">
          <p className="mb-1 text-xs font-bold uppercase tracking-wider text-muted-foreground">Стоимость</p>
          <p className="whitespace-pre-line text-sm leading-relaxed">{info.priceText}</p>
        </div>
      )}
      {info?.contactText && (
        <div className="mx-auto mt-3 max-w-md rounded-2xl border px-5 py-4 text-left">
          <p className="mb-1 text-xs font-bold uppercase tracking-wider text-muted-foreground">Как оплатить / связаться</p>
          <p className="whitespace-pre-line text-sm leading-relaxed">{info.contactText}</p>
        </div>
      )}
      <Link
        to="/feedback"
        className="mt-6 inline-flex min-h-11 items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground transition-transform duration-200 hover:scale-[1.02] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        <MessageCircleQuestion className="h-4 w-4" aria-hidden /> Написать учителю
      </Link>
    </div>
  );
}
