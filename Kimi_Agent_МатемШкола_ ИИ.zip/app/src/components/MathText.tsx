import katex from "katex";
import "katex/dist/katex.min.css";
import { useMemo } from "react";

/**
 * Рендерит текст с LaTeX-формулами в разделителях $$...$$ (блочные) и $...$ (строчные).
 */
function renderSegment(seg: { math: boolean; display: boolean; content: string }, key: number) {
  if (!seg.math) {
    return <span key={key}>{seg.content}</span>;
  }
  const html = katex.renderToString(seg.content, {
    displayMode: seg.display,
    throwOnError: false,
    strict: false,
  });
  return <span key={key} dangerouslySetInnerHTML={{ __html: html }} />;
}

export function MathText({ text, className }: { text: string; className?: string }) {
  const segments = useMemo(() => {
    const out: { math: boolean; display: boolean; content: string }[] = [];
    // сначала $$...$$, потом $...$
    const regex = /\$\$([^$]+)\$\$|\$([^$]+)\$/g;
    let last = 0;
    let m: RegExpExecArray | null;
    while ((m = regex.exec(text)) !== null) {
      if (m.index > last) {
        out.push({ math: false, display: false, content: text.slice(last, m.index) });
      }
      if (m[1] !== undefined) {
        out.push({ math: true, display: true, content: m[1] });
      } else {
        out.push({ math: true, display: false, content: m[2] });
      }
      last = m.index + m[0].length;
    }
    if (last < text.length) {
      out.push({ math: false, display: false, content: text.slice(last) });
    }
    return out;
  }, [text]);

  return <span className={className}>{segments.map(renderSegment)}</span>;
}

/** Многострочный текст: разбивает по \n и рендерит каждую строку */
export function MathParagraphs({ text, className }: { text: string; className?: string }) {
  const lines = text.split(/\n+/).filter((l) => l.trim().length > 0);
  return (
    <div className={className}>
      {lines.map((line, i) => (
        <p key={i} className="mb-2 last:mb-0">
          <MathText text={line} />
        </p>
      ))}
    </div>
  );
}
