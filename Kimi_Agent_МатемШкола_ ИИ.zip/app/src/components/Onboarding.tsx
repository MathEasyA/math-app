import { useState } from "react";
import {
  ArrowRight,
  BookOpenCheck,
  CheckCircle2,
  ClipboardCheck,
  GraduationCap,
  Library,
  Loader2,
  Send,
  XCircle,
} from "lucide-react";

import { MathParagraphs, MathText } from "@/components/MathText";
import { Button } from "@/components/ui/button";
import { trpc } from "@/providers/trpc";

type PlanTask = { topicId: string; topicTitle: string; grade: number; count: number };
type Mode = "free" | "course";

type Phase =
  | { kind: "pick-grade" }
  | { kind: "pick-mode" }
  | { kind: "intro" }
  | { kind: "loading"; index: number }
  | { kind: "answering"; index: number; taskId: number; question: string }
  | { kind: "feedback"; index: number; question: string; correct: boolean; answer: string; solution: string }
  | { kind: "done"; mode: Mode };

/**
 * Первый вход ученика: выбор класса → выбор режима (свободный банк заданий
 * или обучение) → для обучения входное тестирование по темам прошлых лет.
 */
export function Onboarding({ initialGrade, initialMode }: { initialGrade: number | null; initialMode: Mode | null }) {
  const utils = trpc.useUtils();
  const [phase, setPhase] = useState<Phase>(
    !initialGrade ? { kind: "pick-grade" } : !initialMode ? { kind: "pick-mode" } : { kind: "intro" },
  );
  const [grade, setGrade] = useState<number | null>(initialGrade);
  const [plan, setPlan] = useState<PlanTask[] | null>(null);
  const [answer, setAnswer] = useState("");
  const [results, setResults] = useState<boolean[]>([]);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const setGradeMutation = trpc.learning.setGrade.useMutation();
  const setModeMutation = trpc.learning.setMode.useMutation();
  const planQuery = trpc.learning.placementPlan.useQuery(undefined, { enabled: false });
  const taskMutation = trpc.learning.placementTask.useMutation();
  const checkMutation = trpc.learning.placementCheck.useMutation();
  const finishMutation = trpc.learning.placementFinish.useMutation({
    onSuccess: () => {
      // auth.me инвалидируется по кнопке финала — иначе онбординг размонтируется раньше экрана результата
      setPhase({ kind: "done", mode: "course" });
    },
    onError: (err) => setErrorMsg(err.message),
  });

  const pickGrade = (g: number) => {
    setGrade(g);
    setGradeMutation.mutate(
      { grade: g },
      {
        onSuccess: async () => {
          await utils.auth.me.invalidate();
          setPhase({ kind: "pick-mode" });
        },
        onError: (err) => setErrorMsg(err.message),
      },
    );
  };

  const pickMode = (m: Mode) => {
    setErrorMsg(null);
    setModeMutation.mutate(
      { mode: m },
      {
        onSuccess: () => {
          if (m === "free") {
            setPhase({ kind: "done", mode: "free" });
          } else {
            setPhase({ kind: "intro" });
          }
        },
        onError: (err) => setErrorMsg(err.message),
      },
    );
  };

  const startTest = async () => {
    setErrorMsg(null);
    const { data } = await planQuery.refetch();
    if (!data) {
      setErrorMsg("Не удалось загрузить план теста. Обновите страницу.");
      return;
    }
    setPlan(data.tasks);
    setResults([]);
    void loadTask(data.tasks, 0);
  };

  const loadTask = async (tasks: PlanTask[], index: number) => {
    setPhase({ kind: "loading", index });
    setAnswer("");
    try {
      const t = await taskMutation.mutateAsync({ topicId: tasks[index].topicId });
      setPhase({ kind: "answering", index, taskId: t.taskId, question: t.question });
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : "Ошибка генерации задания");
      setPhase({ kind: "intro" });
    }
  };

  const submitAnswer = async () => {
    if (phase.kind !== "answering" || !answer.trim()) return;
    const index = phase.index;
    try {
      const r = await checkMutation.mutateAsync({ taskId: phase.taskId, answer: answer.trim() });
      setResults((prev) => [...prev, r.correct]);
      setPhase({
        kind: "feedback",
        index,
        question: phase.question,
        correct: r.correct,
        answer: r.answer,
        solution: r.solution,
      });
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : "Ошибка проверки");
    }
  };

  const next = () => {
    if (phase.kind !== "feedback" || !plan) return;
    const nextIndex = phase.index + 1;
    if (nextIndex >= plan.length) {
      const correct = [...results].filter(Boolean).length;
      finishMutation.mutate({ correct, total: plan.length });
    } else {
      void loadTask(plan, nextIndex);
    }
  };

  /* ---------- Шаг 1: выбор класса ---------- */
  if (phase.kind === "pick-grade") {
    return (
      <section className="rounded-3xl border-2 border-primary/30 bg-primary/5 p-6 sm:p-10" aria-labelledby="onb-title">
        <GraduationCap className="h-10 w-10 text-primary" aria-hidden />
        <h2 id="onb-title" className="font-display mt-4 text-2xl font-semibold sm:text-3xl">
          В каком ты классе?
        </h2>
        <p className="mt-2 max-w-xl text-muted-foreground">
          Это нужно, чтобы подобрать задания по твоему уровню. Потом выберешь, как заниматься:
          свободно или по программе обучения.
        </p>
        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {[8, 9, 10, 11].map((g) => (
            <button
              key={g}
              onClick={() => pickGrade(g)}
              disabled={setGradeMutation.isPending}
              className="font-display min-h-20 rounded-2xl border bg-card text-2xl font-semibold transition-all duration-200 hover:-translate-y-0.5 hover:border-primary hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-50"
            >
              {g}
            </button>
          ))}
        </div>
        {errorMsg && <p role="alert" className="mt-4 text-sm font-semibold text-destructive">{errorMsg}</p>}
      </section>
    );
  }

  /* ---------- Шаг 2: выбор режима ---------- */
  if (phase.kind === "pick-mode") {
    return (
      <section className="rounded-3xl border-2 border-primary/30 bg-primary/5 p-6 sm:p-10" aria-labelledby="onb-mode">
        <Library className="h-10 w-10 text-primary" aria-hidden />
        <h2 id="onb-mode" className="font-display mt-4 text-2xl font-semibold sm:text-3xl">
          Как будешь заниматься?
        </h2>
        <p className="mt-2 max-w-xl text-muted-foreground">
          Выбери формат: свободный доступ ко всем темам и заданиям или обучение шаг за шагом.
        </p>
        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          <button
            onClick={() => pickMode("free")}
            disabled={setModeMutation.isPending}
            className="group rounded-2xl border bg-card p-5 text-left transition-all duration-200 hover:-translate-y-0.5 hover:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-50"
          >
            <Library className="h-8 w-8 text-primary" aria-hidden />
            <p className="font-display mt-3 text-lg font-semibold">Свободный банк заданий</p>
            <p className="mt-1 text-sm text-muted-foreground">
              Все темы всех классов и практика открыты сразу. Решай что хочешь и в любом порядке — без тестов и ограничений.
            </p>
          </button>
          <button
            onClick={() => pickMode("course")}
            disabled={setModeMutation.isPending}
            className="group rounded-2xl border bg-card p-5 text-left transition-all duration-200 hover:-translate-y-0.5 hover:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-50"
          >
            <BookOpenCheck className="h-8 w-8 text-primary" aria-hidden />
            <p className="font-display mt-3 text-lg font-semibold">Обучение</p>
            <p className="mt-1 text-sm text-muted-foreground">
              Сначала входное тестирование по темам прошлых лет, затем темы твоего класса открываются по порядку:
              теория → тест → практика. Новая тема — только после сдачи предыдущей.
            </p>
          </button>
        </div>
        {setModeMutation.isPending && (
          <p className="mt-4 flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> Сохраняем выбор…
          </p>
        )}
        {errorMsg && <p role="alert" className="mt-4 text-sm font-semibold text-destructive">{errorMsg}</p>}
      </section>
    );
  }

  /* ---------- Шаг 3 (обучение): перед тестом ---------- */
  if (phase.kind === "intro") {
    return (
      <section className="rounded-3xl border-2 border-primary/30 bg-primary/5 p-6 sm:p-10" aria-labelledby="onb-intro">
        <ClipboardCheck className="h-10 w-10 text-primary" aria-hidden />
        <h2 id="onb-intro" className="font-display mt-4 text-2xl font-semibold sm:text-3xl">
          Входное тестирование
        </h2>
        <p className="mt-2 max-w-xl text-muted-foreground">
          {grade === 8
            ? "Несколько базовых заданий — проверим, что помнишь из прошлых лет."
            : "По 1–2 задания из каждого пройденного класса — проверим базу прошлых лет."}{" "}
          Чтобы начать обучение, нужно ответить на все вопросы. После теста откроется первая тема {grade} класса,
          а дальше — каждая следующая тема после сдачи теста по предыдущей.
        </p>
        <Button className="mt-6 min-h-12 gap-2 px-6" onClick={startTest} disabled={taskMutation.isPending}>
          {taskMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : null}
          Начать тестирование
        </Button>
        {errorMsg && <p role="alert" className="mt-4 text-sm font-semibold text-destructive">{errorMsg}</p>}
      </section>
    );
  }

  /* ---------- Генерация задания ---------- */
  if (phase.kind === "loading") {
    const total = plan?.length ?? 0;
    return (
      <section className="flex flex-col items-center gap-4 rounded-3xl border bg-card p-10 text-center" aria-live="polite">
        <Loader2 className="h-8 w-8 animate-spin text-primary" aria-hidden />
        <p className="font-semibold">Задание {phase.index + 1} из {total}…</p>
        <ProgressLine done={phase.index} total={total} results={results} />
      </section>
    );
  }

  /* ---------- Ответ на задание ---------- */
  if (phase.kind === "answering" && plan) {
    const total = plan.length;
    return (
      <section className="rounded-3xl border bg-card p-6 sm:p-8" aria-labelledby="onb-task">
        <div className="flex items-center justify-between gap-3">
          <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
            Входное тестирование · задание {phase.index + 1} из {total}
          </p>
          <p className="text-xs text-muted-foreground">{plan[phase.index].topicTitle}</p>
        </div>
        <ProgressLine done={phase.index} total={total} results={results} />
        <div className="mt-4 text-lg leading-relaxed"><MathText text={phase.question} /></div>
        <form
          className="mt-6 flex flex-col gap-3 sm:flex-row"
          onSubmit={(e) => {
            e.preventDefault();
            void submitAnswer();
          }}
        >
          <input
            autoFocus
            value={answer}
            onChange={(e) => setAnswer(e.target.value)}
            placeholder="Ваш ответ (число или дробь)"
            autoComplete="off"
            className="min-h-12 flex-1 rounded-xl border bg-background px-4 text-base focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            aria-label="Ваш ответ"
          />
          <Button type="submit" className="min-h-12 gap-2" disabled={!answer.trim() || checkMutation.isPending}>
            {checkMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Send className="h-4 w-4" aria-hidden />}
            Ответить
          </Button>
        </form>
        {errorMsg && <p role="alert" className="mt-4 text-sm font-semibold text-destructive">{errorMsg}</p>}
      </section>
    );
  }

  /* ---------- Разбор задания ---------- */
  if (phase.kind === "feedback" && plan) {
    const total = plan.length;
    const last = phase.index + 1 >= total;
    return (
      <section className="flex flex-col gap-4">
        <div
          className={`rounded-3xl border-2 p-6 sm:p-8 ${phase.correct ? "border-success/50 bg-success/10" : "border-destructive/40 bg-destructive/5"}`}
          aria-live="polite"
        >
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              {phase.correct ? (
                <CheckCircle2 className="h-8 w-8 text-success" aria-hidden />
              ) : (
                <XCircle className="h-8 w-8 text-destructive" aria-hidden />
              )}
              <div>
                <p className="font-display text-xl font-semibold">{phase.correct ? "Верно!" : "Неверно"}</p>
                {!phase.correct && (
                  <p className="text-sm text-muted-foreground">
                    Правильный ответ: <span className="font-bold text-foreground"><MathText text={`$${phase.answer}$`} /></span>
                  </p>
                )}
              </div>
            </div>
            <p className="shrink-0 text-xs font-bold text-muted-foreground">{phase.index + 1} / {total}</p>
          </div>
          <ProgressLine done={phase.index + 1} total={total} results={results} />
          {!phase.correct && (
            <div className="mt-5 border-t pt-5">
              <p className="mb-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">Решение</p>
              <MathParagraphs text={phase.solution} className="leading-relaxed" />
            </div>
          )}
        </div>
        <Button className="min-h-12 gap-2 self-start px-6" onClick={next} disabled={finishMutation.isPending}>
          {finishMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : null}
          {last ? "Завершить тестирование" : "Следующее задание"}
          {!last && <ArrowRight className="h-4 w-4" aria-hidden />}
        </Button>
      </section>
    );
  }

  /* ---------- Финал ---------- */
  if (phase.kind === "done" && phase.mode === "free") {
    return (
      <section className="rounded-3xl border-2 border-success/40 bg-success/5 p-6 sm:p-10 text-center" aria-live="polite">
        <CheckCircle2 className="mx-auto h-12 w-12 text-success" aria-hidden />
        <h2 className="font-display mt-4 text-2xl font-semibold sm:text-3xl">Готово, всё открыто!</h2>
        <p className="mx-auto mt-4 max-w-md text-muted-foreground">
          Тебе доступен весь банк заданий: теория и практика по всем темам {grade} класса и остальных классов,
          а также разделы ОГЭ и ЕГЭ. Решай в любом порядке.
        </p>
        <Button className="mt-6 min-h-12 gap-2 px-6" onClick={() => utils.invalidate()}>
          Перейти к заданиям <ArrowRight className="h-4 w-4" aria-hidden />
        </Button>
      </section>
    );
  }

  /* ---------- Финал (обучение): результат тестирования ---------- */
  const correct = results.filter(Boolean).length;
  const total = plan?.length ?? 0;
  const pct = total > 0 ? Math.round((correct / total) * 100) : 0;
  return (
    <section className="rounded-3xl border-2 border-success/40 bg-success/5 p-6 sm:p-10 text-center" aria-live="polite">
      <CheckCircle2 className="mx-auto h-12 w-12 text-success" aria-hidden />
      <h2 className="font-display mt-4 text-2xl font-semibold sm:text-3xl">Тестирование завершено!</h2>
      <p className="font-display mt-3 text-4xl font-semibold">{correct} из {total}</p>
      <p className="mt-1 text-sm text-muted-foreground">верных ответов · {pct}%</p>
      <p className="mx-auto mt-4 max-w-md text-muted-foreground">
        Открыта первая тема {grade} класса. Изучи теорию, сдай тест по теме (ошибок не больше 20%) —
        откроется практика, а после неё следующая тема.
      </p>
      <Button className="mt-6 min-h-12 gap-2 px-6" onClick={() => utils.invalidate()}>
        Начать обучение <ArrowRight className="h-4 w-4" aria-hidden />
      </Button>
    </section>
  );
}

/** Полоса прогресса теста: квадратики по заданиям */
function ProgressLine({ done, total, results }: { done: number; total: number; results: boolean[] }) {
  if (total === 0) return null;
  return (
    <div className="mt-4 flex flex-wrap items-center gap-1.5" aria-label={`Пройдено ${done} из ${total}`}>
      {Array.from({ length: total }).map((_, i) => {
        const state = i < results.length ? (results[i] ? "ok" : "bad") : i === done ? "now" : "todo";
        return (
          <span
            key={i}
            className={`h-2.5 w-7 rounded-full transition-colors ${
              state === "ok" ? "bg-success" : state === "bad" ? "bg-destructive/70" : state === "now" ? "bg-primary" : "bg-muted"
            }`}
          />
        );
      })}
    </div>
  );
}
