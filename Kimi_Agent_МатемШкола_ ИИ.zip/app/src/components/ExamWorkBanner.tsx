import { Link } from "react-router";
import { ClipboardList, Play } from "lucide-react";

import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";

/**
 * Баннер активной контрольной работы: показывается ученику на главной
 * и на странице класса, пока контрольная не сдана.
 */
export function ExamWorkBanner() {
  const { user, isAuthenticated } = useAuth();
  const myWorks = trpc.examWork.myWorks.useQuery(undefined, {
    enabled: isAuthenticated && user?.role !== "admin",
  });
  const works = myWorks.data?.works ?? [];
  const active = works.filter((w) => w.myStatus !== "done");
  if (!isAuthenticated || user?.role === "admin" || active.length === 0) return null;

  const inProgress = active.find((w) => w.myStatus === "in_progress");

  return (
    <div className="flex flex-col gap-3">
      {active.map((w) => (
        <div
          key={w.id}
          className="flex flex-wrap items-center justify-between gap-3 rounded-3xl border-2 border-primary/40 bg-primary/5 p-4 sm:p-5"
          role="status"
        >
          <div className="flex min-w-0 items-center gap-3">
            <ClipboardList className="h-8 w-8 shrink-0 text-primary" aria-hidden />
            <div className="min-w-0">
              <p className="font-display truncate text-base font-semibold sm:text-lg">{w.title}</p>
              <p className="text-xs text-muted-foreground sm:text-sm">
                Контрольная работа · {w.taskCount} заданий
                {w.myStatus === "in_progress"
                  ? " · начата — темы закрыты до сдачи"
                  : " · на время контрольной темы будут закрыты"}
              </p>
            </div>
          </div>
          <Link
            to={`/exam-work/${w.id}`}
            className="inline-flex min-h-11 items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground transition-transform duration-200 hover:scale-[1.02] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <Play className="h-4 w-4" aria-hidden />
            {w.myStatus === "in_progress" ? "Продолжить" : "Начать"}
          </Link>
        </div>
      ))}
      {inProgress && (
        <p className="px-1 text-xs font-semibold text-muted-foreground">
          Пока контрольная не сдана, доступ к темам и практике закрыт.
        </p>
      )}
    </div>
  );
}
