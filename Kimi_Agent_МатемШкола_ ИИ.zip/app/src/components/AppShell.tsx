import { Link, NavLink, useNavigate } from "react-router";
import { GraduationCap, Home, LineChart, LogIn, LogOut, MessageCircleQuestion, ShieldCheck, Sigma, UsersRound } from "lucide-react";
import type { ReactNode } from "react";

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ThemeToggle } from "@/components/ThemeToggle";
import { useAuth } from "@/hooks/useAuth";
import { cn } from "@/lib/utils";
import { trpc } from "@/providers/trpc";

const gradeLinks = [
  { to: "/class/8", label: "8 класс" },
  { to: "/class/9", label: "9 класс" },
  { to: "/class/10", label: "10 класс" },
  { to: "/class/11", label: "11 класс" },
];

function Logo() {
  return (
    <Link to="/" className="flex items-center gap-2.5 rounded-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
      <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
        <Sigma className="h-5 w-5" aria-hidden />
      </span>
      <span className="leading-tight">
        <span className="font-display block text-lg font-semibold">MathEasy</span>
        <span className="block text-xs text-muted-foreground">теория · практика · экзамены</span>
      </span>
    </Link>
  );
}

function UserMenu() {
  const { user, isAuthenticated, isLoading, logout } = useAuth();
  const navigate = useNavigate();

  if (isLoading) {
    return <div className="h-10 w-10 animate-pulse rounded-full bg-muted" />;
  }
  if (!isAuthenticated || !user) {
    return (
      <Button variant="default" size="sm" className="h-10 gap-2" onClick={() => navigate("/login")}>
        <LogIn className="h-4 w-4" aria-hidden />
        <span className="hidden sm:inline">Войти</span>
      </Button>
    );
  }
  const initials = (user.name ?? "У").trim().charAt(0).toUpperCase();
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          className="flex h-11 items-center gap-2 rounded-full p-1 transition-colors hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          aria-label="Меню пользователя"
        >
          <Avatar className="h-9 w-9">
            {user.avatar ? <AvatarImage src={user.avatar} alt="" /> : null}
            <AvatarFallback className="bg-primary text-primary-foreground text-sm font-bold">
              {initials}
            </AvatarFallback>
          </Avatar>
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <div className="px-2 py-1.5">
          <p className="truncate text-sm font-semibold">{user.name ?? "Ученик"}</p>
          <p className="truncate text-xs text-muted-foreground">{user.email ?? ""}</p>
        </div>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={() => navigate("/progress")} className="cursor-pointer">
          <LineChart className="mr-2 h-4 w-4" aria-hidden /> Мой прогресс
        </DropdownMenuItem>
        {user.role === "admin" && (
          <>
            <DropdownMenuItem onClick={() => navigate("/admin")} className="cursor-pointer">
              <ShieldCheck className="mr-2 h-4 w-4" aria-hidden /> Кабинет учителя
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate("/users")} className="cursor-pointer">
              <UsersRound className="mr-2 h-4 w-4" aria-hidden /> Пользователи
            </DropdownMenuItem>
          </>
        )}
        <DropdownMenuItem onClick={() => logout()} className="cursor-pointer text-destructive focus:text-destructive">
          <LogOut className="mr-2 h-4 w-4" aria-hidden /> Выйти
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const unreadQuery = trpc.teacher.unreadFeedbackCount.useQuery(undefined, {
    enabled: isAdmin,
    refetchInterval: 60_000,
  });
  const unread = unreadQuery.data ?? 0;

  return (
    <div className="min-h-dvh bg-background">
      {/* Десктоп: фиксированная боковая панель */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col border-r bg-sidebar-background px-4 py-6 lg:flex">
        <Logo />
        <nav className="mt-8 flex flex-1 flex-col gap-1" aria-label="Основная навигация">
          <NavItem to="/" icon={<Home className="h-4 w-4" aria-hidden />} label="Главная" end />
          <p className="mb-1 mt-5 px-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Классы</p>
          {gradeLinks.map((g) => (
            <NavItem key={g.to} to={g.to} icon={<GraduationCap className="h-4 w-4" aria-hidden />} label={g.label} />
          ))}
          <p className="mb-1 mt-5 px-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Экзамены</p>
          <NavItem to="/exams/oge" label="ОГЭ · 9 класс" />
          <NavItem to="/exams/ege" label="ЕГЭ · 11 класс" />
          <p className="mb-1 mt-5 px-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Ученик</p>
          <NavItem to="/progress" icon={<LineChart className="h-4 w-4" aria-hidden />} label="Мой прогресс" />
          <NavItem to="/feedback" icon={<MessageCircleQuestion className="h-4 w-4" aria-hidden />} label="Обратная связь" />
          {isAdmin && (
            <>
              <p className="mb-1 mt-5 px-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Учитель</p>
              <NavItem
                to="/admin"
                icon={<ShieldCheck className="h-4 w-4" aria-hidden />}
                label="Кабинет учителя"
                badge={unread > 0 ? unread : undefined}
              />
              <NavItem
                to="/users"
                icon={<UsersRound className="h-4 w-4" aria-hidden />}
                label="Пользователи"
              />
            </>
          )}
        </nav>
        <div className="flex items-center justify-between border-t pt-4">
          <UserMenu />
          <ThemeToggle />
        </div>
      </aside>

      {/* Мобильный хедер */}
      <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b bg-sidebar-background/90 px-4 backdrop-blur lg:hidden">
        <Logo />
        <div className="flex items-center gap-2">
          <ThemeToggle />
          <UserMenu />
        </div>
      </header>

      {/* Контент */}
      <main className="pb-24 lg:pb-10 lg:pl-64">
        <div className="mx-auto w-full max-w-5xl px-4 py-6 sm:px-6 lg:py-10">{children}</div>
      </main>

      {/* Мобильная нижняя навигация */}
      <nav
        className="fixed inset-x-0 bottom-0 z-30 flex items-stretch justify-around border-t bg-sidebar-background/95 backdrop-blur lg:hidden"
        style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
        aria-label="Нижняя навигация"
      >
        <BottomItem to="/" icon={<Home className="h-5 w-5" aria-hidden />} label="Главная" end />
        <BottomItem to="/class/9" icon={<GraduationCap className="h-5 w-5" aria-hidden />} label="Классы" />
        <BottomItem to="/exams" icon={<Sigma className="h-5 w-5" aria-hidden />} label="Экзамены" />
        <BottomItem to="/progress" icon={<LineChart className="h-5 w-5" aria-hidden />} label="Прогресс" />
      </nav>
    </div>
  );
}

function NavItem({ to, label, icon, end, badge }: { to: string; label: string; icon?: ReactNode; end?: boolean; badge?: number }) {
  return (
    <NavLink
      to={to}
      end={end}
      className={({ isActive }) =>
        cn(
          "flex min-h-11 items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm font-semibold transition-colors duration-200",
          "hover:bg-accent hover:text-accent-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
          isActive ? "bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground" : "text-foreground/80",
        )
      }
    >
      {icon}
      <span className="flex-1">{label}</span>
      {badge !== undefined && (
        <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-destructive px-1.5 text-[11px] font-bold text-destructive-foreground">
          {badge}
        </span>
      )}
    </NavLink>
  );
}

function BottomItem({ to, label, icon, end }: { to: string; label: string; icon: ReactNode; end?: boolean }) {
  return (
    <NavLink
      to={to}
      end={end}
      className={({ isActive }) =>
        cn(
          "flex min-h-14 flex-1 flex-col items-center justify-center gap-0.5 py-2 text-[11px] font-semibold transition-colors",
          "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-ring",
          isActive ? "text-primary" : "text-muted-foreground",
        )
      }
    >
      {icon}
      {label}
    </NavLink>
  );
}
