
import { readFileSync } from "fs";
import mysql from "mysql2/promise";
const env = {};
for (const line of readFileSync("/mnt/agents/output/app/.env", "utf8").split("\n")) {
  const t = line.trim();
  if (t && !t.startsWith("#") && t.includes("=")) {
    const i = t.indexOf("=");
    env[t.slice(0, i)] = t.slice(i + 1);
  }
}
const conn = await mysql.createConnection(env.DATABASE_URL);
await conn.query("DELETE FROM attempts WHERE userId IN (2000011, 2000020, 2000021)");
await conn.query("DELETE FROM users WHERE id IN (2000011, 2000020, 2000021)");
console.log("cleared");
await conn.end();
