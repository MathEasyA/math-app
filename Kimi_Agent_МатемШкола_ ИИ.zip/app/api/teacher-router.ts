import { desc, eq, sql } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { z } from "zod";

import { attempts, feedback, settings, users } from "@db/schema";
import { getDb } from "./queries/connection";
import { adminQuery, authedQuery, createRouter, publicQuery } from "./middleware";
import { getSettings, notifyTeacher } from "./lib/telegram";
import { findPracticeTarget } from "@contracts/content";

/** Доступ к практике: админ всегда, ученик — пока не истёк accessUntil */
export function hasAccess(user: { role: string; accessUntil: Date | null }): boolean {
  if (user.role === "admin") return true;
  return user.accessUntil !== null && user.accessUntil.getTime() > Date.now();
}

export const teacherRouter = createRouter({
  /** Публичная информация для экрана закрытого доступа и страницы входа */
  publicInfo: publicQuery.query(async () => {
    const s = await getSettings();
    return {
      priceText: s.priceText ?? "",
      contactText: s.contactText ?? "",
    };
  }),

  /** Мой статус доступа */
  myAccess: authedQuery.query(({ ctx }) => ({
    isAdmin: ctx.user.role === "admin",
    hasAccess: hasAccess(ctx.user),
    accessUntil: ctx.user.accessUntil,
    /** true, если сейчас действует бесплатный пробный период */
    trialActive: ctx.user.trialGranted && hasAccess(ctx.user),
    /** true, если пробный период уже закончился (а платный доступ не выдан) */
    trialExpired: ctx.user.trialGranted && !hasAccess(ctx.user),
  })),

  // ---------- Настройки (только учитель) ----------

  getSettings: adminQuery.query(async () => {
    const s = await getSettings();
    return {
      telegramBotToken: s.telegramBotToken ?? "",
      telegramChatId: s.telegramChatId ?? "",
      priceText: s.priceText ?? "",
      contactText: s.contactText ?? "",
    };
  }),

  updateSettings: adminQuery
    .input(
      z.object({
        telegramBotToken: z.string().max(128),
        telegramChatId: z.string().max(64),
        priceText: z.string().max(2000),
        contactText: z.string().max(2000),
      }),
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const s = await getSettings();
      await db
        .update(settings)
        .set({
          telegramBotToken: input.telegramBotToken.trim() || null,
          telegramChatId: input.telegramChatId.trim() || null,
          priceText: input.priceText.trim() || null,
          contactText: input.contactText.trim() || null,
        })
        .where(eq(settings.id, s.id));
      return { ok: true };
    }),

  testTelegram: adminQuery.mutation(async ({ ctx }) => {
    const ok = await notifyTeacher(
      `✅ MathEasy: связь настроена! Уведомления о прогрессе учеников и обратной связи будут приходить сюда. (${ctx.user.name ?? "учитель"})`,
    );
    if (!ok) {
      throw new TRPCError({
        code: "PRECONDITION_FAILED",
        message: "Не удалось отправить. Проверьте токен бота и Chat ID, затем сохраните настройки и повторите.",
      });
    }
    return { ok: true };
  }),

  // ---------- Ученики (только учитель) ----------

  students: adminQuery.query(async () => {
    const db = getDb();
    const rows = await db
      .select({
        id: users.id,
        name: users.name,
        email: users.email,
        accessUntil: users.accessUntil,
        trialGranted: users.trialGranted,
        lastSignInAt: users.lastSignInAt,
        solved: sql<number>`(select count(*) from ${attempts} where ${attempts.userId} = ${users.id})`.mapWith(Number),
        correct: sql<number>`(select coalesce(sum(${attempts.correct}),0) from ${attempts} where ${attempts.userId} = ${users.id})`.mapWith(Number),
      })
      .from(users)
      .where(eq(users.role, "user"))
      .orderBy(desc(users.lastSignInAt));
    return rows;
  }),

  /**
   * Все пользователи приложения с прогрессом:
   * общие итоги + разбивка по разделам и темам.
   */
  usersWithProgress: adminQuery.query(async () => {
    const db = getDb();
    const allUsers = await db
      .select({
        id: users.id,
        name: users.name,
        email: users.email,
        role: users.role,
        accessUntil: users.accessUntil,
        trialGranted: users.trialGranted,
        lastSignInAt: users.lastSignInAt,
        createdAt: users.createdAt,
        grade: users.grade,
        learningMode: users.learningMode,
        placementDone: users.placementDone,
        placementScore: users.placementScore,
        placementTotal: users.placementTotal,
      })
      .from(users)
      .orderBy(desc(users.lastSignInAt));

    const stats = await db
      .select({
        userId: attempts.userId,
        sectionId: attempts.sectionId,
        topicId: attempts.topicId,
        total: sql<number>`count(*)`.mapWith(Number),
        correct: sql<number>`coalesce(sum(${attempts.correct}),0)`.mapWith(Number),
        lastAt: sql<Date>`max(${attempts.createdAt})`.mapWith(attempts.createdAt),
      })
      .from(attempts)
      .groupBy(attempts.userId, attempts.sectionId, attempts.topicId);

    const byUser = new Map<number, typeof stats>();
    for (const s of stats) {
      const list = byUser.get(s.userId);
      if (list) list.push(s);
      else byUser.set(s.userId, [s]);
    }

    return allUsers.map((u) => {
      const topics = (byUser.get(u.id) ?? []).sort((a, b) => b.lastAt.getTime() - a.lastAt.getTime());
      const solved = topics.reduce((acc, t) => acc + t.total, 0);
      const correct = topics.reduce((acc, t) => acc + t.correct, 0);
      const lastAttemptAt = topics.length > 0 ? topics[0].lastAt : null;
      return { ...u, solved, correct, lastAttemptAt, topics };
    });
  }),

  setAccess: adminQuery
    .input(
      z.object({
        userId: z.number().int().positive(),
        /** дней доступа от текущего момента; 0 — закрыть доступ */
        days: z.number().int().min(0).max(3660),
      }),
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const accessUntil =
        input.days === 0 ? null : new Date(Date.now() + input.days * 24 * 60 * 60 * 1000);
      // Выданный учителем доступ — уже не пробный период
      await db.update(users).set({ accessUntil, trialGranted: false }).where(eq(users.id, input.userId));
      return { ok: true, accessUntil };
    }),

  // ---------- Обратная связь ----------

  submitFeedback: authedQuery
    .input(
      z.object({
        category: z.enum(["question", "suggestion", "problem"]),
        message: z.string().min(3, "Напишите хотя бы пару слов").max(3000),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db.insert(feedback).values({
        userId: ctx.user.id,
        category: input.category,
        message: input.message,
      });
      const catLabel =
        input.category === "question" ? "Вопрос" : input.category === "suggestion" ? "Предложение" : "Проблема";
      // Уведомление учителю — в фоне, не блокируем ответ
      void notifyTeacher(
        `📩 ${catLabel} от ученика\n👤 ${ctx.user.name ?? "Без имени"}${ctx.user.email ? ` (${ctx.user.email})` : ""}\n\n${input.message}`,
      );
      return { ok: true };
    }),

  feedbackList: adminQuery.query(async () => {
    const db = getDb();
    const rows = await db
      .select({
        id: feedback.id,
        category: feedback.category,
        message: feedback.message,
        read: feedback.read,
        createdAt: feedback.createdAt,
        userName: users.name,
        userEmail: users.email,
      })
      .from(feedback)
      .innerJoin(users, eq(feedback.userId, users.id))
      .orderBy(desc(feedback.createdAt))
      .limit(100);
    return rows;
  }),

  unreadFeedbackCount: adminQuery.query(async () => {
    const db = getDb();
    const rows = await db
      .select({ count: sql<number>`count(*)`.mapWith(Number) })
      .from(feedback)
      .where(eq(feedback.read, false));
    return rows[0]?.count ?? 0;
  }),

  markFeedbackRead: adminQuery
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(feedback).set({ read: true }).where(eq(feedback.id, input.id));
      return { ok: true };
    }),

  markAllFeedbackRead: adminQuery.mutation(async () => {
    const db = getDb();
    await db.update(feedback).set({ read: true }).where(eq(feedback.read, false));
    return { ok: true };
  }),
});

/** Отчёт учителю после пройденного блока темы (каждые 5 заданий по теме) */
export async function maybeSendTopicReport(opts: {
  userId: number;
  userName: string | null;
  sectionId: string;
  topicId: string;
}) {
  const db = getDb();
  const rows = await db
    .select({
      total: sql<number>`count(*)`.mapWith(Number),
      correct: sql<number>`coalesce(sum(${attempts.correct}),0)`.mapWith(Number),
    })
    .from(attempts)
    .where(
      sql`${attempts.userId} = ${opts.userId} and ${attempts.sectionId} = ${opts.sectionId} and ${attempts.topicId} = ${opts.topicId}`,
    );
  const { total, correct } = rows[0] ?? { total: 0, correct: 0 };
  if (total === 0 || total % 5 !== 0) return;

  const target = findPracticeTarget(opts.sectionId, opts.topicId);
  const pct = Math.round((correct / total) * 100);
  await notifyTeacher(
    `📊 Блок пройден!\n👤 ${opts.userName ?? "Ученик"}\n📚 ${target?.sectionTitle ?? opts.sectionId} · ${target?.topicTitle ?? opts.topicId}\n✏️ Решено заданий: ${total}, верно: ${correct} (${pct}%)`,
  );
}
