import { authRouter } from "./auth-router";
import { examWorkRouter } from "./exam-work-router";
import { learningRouter } from "./learning-router";
import { createRouter, publicQuery } from "./middleware";
import { tasksRouter } from "./tasks-router";
import { teacherRouter } from "./teacher-router";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  learning: learningRouter,
  tasks: tasksRouter,
  teacher: teacherRouter,
  examWork: examWorkRouter,
});

export type AppRouter = typeof appRouter;
