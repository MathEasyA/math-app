import { generateObject } from "ai";
import { and, desc, eq, sql } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { z } from "zod";

import { findGrade } from "@contracts/content";
import { examWorkAttempts, examWorkTasks, examWorks, users } from "@db/schema";
import { getDb } from "./queries/connection";
import { getActiveExamAttempt } from "./queries/exam-works";
import { adminQuery, authedQuery, createRouter } from "./middleware";
import { kimiGw } from "./ai/provider";
import { listModels } from "./lib/ai-client";
import { answersEqual, toUserFacingError } from "./tasks-router";
import { notifyTeacher } from "./lib/telegram";

/** Уведомление учителю, не роняет запрос при ошибке */
function notifyTeacherSafe(text: string): Promise<boolean> {
  return notifyTeacher(text).catch(() => false);
}

const quizSchema = z.object({
  questions: z
    .array(
      z.object({
        question: z.string().describe("Условие задачи на русском, формулы в LaTeX внутри $...$"),
        answer: z.string().describe("Краткий ответ: число или дробь a/b, без единиц и пояснений"),
      }),
    )
    .min(1)
    .max(4),
});

export const examWorkRouter = createRouter({
  /* ---------------- Учитель ---------------- */

  /** Создать контрольную: задания генерируются один раз, у всех учеников одинаковые */
  create: adminQuery
    .input(
      z.object({
        title: z.string().min(1).max(200),
        grade: z.number().int().min(8).max(11),
        topicIds: z.array(z.string().min(1).max(64)).min(1).max(8),
        tasksPerTopic: z.number().int().min(1).max(3).default(1),
      }),
    )
    .mutation(async ({ input }) => {
      const grade = findGrade(input.grade);
      if (!grade) throw new TRPCError({ code: "NOT_FOUND", message: "Класс не найден." });
      const topics = input.topicIds.map((id) => {
        const t = grade.topics.find((x) => x.id === id);
        if (!t) throw new TRPCError({ code: "NOT_FOUND", message: `Тема ${id} не найдена.` });
        return t;
      });

      const db = getDb();
      const inserted = await db.insert(examWorks).values({
        title: input.title,
        grade: input.grade,
        topicIds: input.topicIds,
        status: "active",
      });
      const workId = Number(inserted[0].insertId);

      // Генерация заданий по каждой теме
      const { defaultModelId } = await listModels();
      let orderIndex = 0;
      const allTasks: { topicId: string; orderIndex: number; question: string; answer: string }[] = [];
      for (const topic of topics) {
        const prompt = [
          `Ты — составитель контрольной работы по школьной математике для ${input.grade} класса.`,
          `Тема: «${topic.title}» (${topic.description}).`,
          `Составь ${input.tasksPerTopic} задач(и) уровня типовой контрольной. Каждая — с единственным ответом: число или дробь a/b, без единиц измерения.`,
          `Числа подбирай «красивые». Формулы — в LaTeX между $...$.`,
          `Верни строго массив из ${input.tasksPerTopic} объектов.`,
        ].join("\n");
        let quiz: z.infer<typeof quizSchema>;
        try {
          const result = await generateObject({
            model: kimiGw(defaultModelId),
            schema: quizSchema,
            prompt,
            providerOptions: { "kimi-gw": { max_completion_tokens: 4000 } },
          });
          quiz = result.object;
        } catch (err) {
          // откатываем созданную работу, чтобы не висела пустая
          await db.delete(examWorks).where(eq(examWorks.id, workId));
          throw toUserFacingError(err);
        }
        for (const q of quiz.questions.slice(0, input.tasksPerTopic)) {
          allTasks.push({ topicId: topic.id, orderIndex: orderIndex++, question: q.question, answer: q.answer });
        }
      }
      if (allTasks.length === 0) {
        await db.delete(examWorks).where(eq(examWorks.id, workId));
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "ИИ не вернул задания. Попробуйте ещё раз." });
      }
      await db.insert(examWorkTasks).values(allTasks.map((t) => ({ ...t, workId })));
      return { id: workId, taskCount: allTasks.length };
    }),

  /** Список контрольных (учитель) */
  list: adminQuery.query(async () => {
    const db = getDb();
    const works = await db.select().from(examWorks).orderBy(desc(examWorks.createdAt));
    const taskCounts = await db
      .select({ workId: examWorkTasks.workId, cnt: sql<number>`count(*)`.mapWith(Number) })
      .from(examWorkTasks)
      .groupBy(examWorkTasks.workId);
    const attemptCounts = await db
      .select({ workId: examWorkAttempts.workId, cnt: sql<number>`count(*)`.mapWith(Number) })
      .from(examWorkAttempts)
      .groupBy(examWorkAttempts.workId);
    const tc = new Map(taskCounts.map((t) => [t.workId, t.cnt]));
    const ac = new Map(attemptCounts.map((t) => [t.workId, t.cnt]));
    return works.map((w) => ({ ...w, taskCount: tc.get(w.id) ?? 0, attemptCount: ac.get(w.id) ?? 0 }));
  }),

  /** Открыть/закрыть контрольную */
  setStatus: adminQuery
    .input(z.object({ workId: z.number().int().positive(), status: z.enum(["active", "closed"]) }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(examWorks).set({ status: input.status }).where(eq(examWorks.id, input.workId));
      return { ok: true };
    }),

  /** Результаты контрольной по ученикам (с ответами для разбора) */
  results: adminQuery
    .input(z.object({ workId: z.number().int().positive() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [work] = await db.select().from(examWorks).where(eq(examWorks.id, input.workId)).limit(1);
      if (!work) throw new TRPCError({ code: "NOT_FOUND", message: "Контрольная не найдена." });
      const tasks = await db
        .select()
        .from(examWorkTasks)
        .where(eq(examWorkTasks.workId, input.workId))
        .orderBy(examWorkTasks.orderIndex);
      const attempts = await db
        .select({
          id: examWorkAttempts.id,
          userId: examWorkAttempts.userId,
          userName: users.name,
          startedAt: examWorkAttempts.startedAt,
          finishedAt: examWorkAttempts.finishedAt,
          correct: examWorkAttempts.correct,
          total: examWorkAttempts.total,
          details: examWorkAttempts.details,
        })
        .from(examWorkAttempts)
        .leftJoin(users, eq(users.id, examWorkAttempts.userId))
        .where(eq(examWorkAttempts.workId, input.workId))
        .orderBy(desc(examWorkAttempts.startedAt));
      return { work, tasks, attempts };
    }),

  /* ---------------- Ученик ---------------- */

  /** Активные контрольные для моего класса + моя текущая незавершённая попытка */
  myWorks: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const grade = ctx.user.grade;
    if (ctx.user.role === "admin" || !grade) return { works: [], activeAttempt: null };
    const works = await db
      .select()
      .from(examWorks)
      .where(and(eq(examWorks.grade, grade), eq(examWorks.status, "active")))
      .orderBy(desc(examWorks.createdAt));
    if (works.length === 0) return { works: [], activeAttempt: null };

    const taskCounts = await db
      .select({ workId: examWorkTasks.workId, cnt: sql<number>`count(*)`.mapWith(Number) })
      .from(examWorkTasks)
      .groupBy(examWorkTasks.workId);
    const tc = new Map(taskCounts.map((t) => [t.workId, t.cnt]));
    const myAttempts = await db
      .select()
      .from(examWorkAttempts)
      .where(eq(examWorkAttempts.userId, ctx.user.id))
      .orderBy(desc(examWorkAttempts.startedAt));
    const byWork = new Map<number, (typeof myAttempts)[number]>();
    for (const a of myAttempts) {
      // берём последнюю попытку по каждой работе
      if (!byWork.has(a.workId)) byWork.set(a.workId, a);
    }
    const activeAttempt = myAttempts.find((a) => a.finishedAt == null) ?? null;
    return {
      works: works.map((w) => {
        const att = byWork.get(w.id);
        return {
          id: w.id,
          title: w.title,
          grade: w.grade,
          taskCount: tc.get(w.id) ?? 0,
          myStatus: att == null ? "new" : att.finishedAt == null ? "in_progress" : "done",
          myScore: att?.finishedAt != null ? { correct: att.correct ?? 0, total: att.total ?? 0 } : null,
        };
      }),
      activeAttempt: activeAttempt ? { workId: activeAttempt.workId } : null,
    };
  }),

  /** Старт контрольной: создаёт попытку и возвращает задания БЕЗ ответов */
  start: authedQuery
    .input(z.object({ workId: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.role === "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Учитель не может проходить контрольную как ученик." });
      }
      const db = getDb();
      const [work] = await db.select().from(examWorks).where(eq(examWorks.id, input.workId)).limit(1);
      if (!work || work.status !== "active") {
        throw new TRPCError({ code: "NOT_FOUND", message: "Контрольная не найдена или уже закрыта." });
      }
      if (!ctx.user.grade || ctx.user.grade !== work.grade) {
        throw new TRPCError({ code: "FORBIDDEN", message: "Эта контрольная не для вашего класса." });
      }
      // нельзя начать вторую, пока не завершена текущая
      const active = await getActiveExamAttempt(ctx.user.id);
      if (active && active.workId !== input.workId) {
        throw new TRPCError({
          code: "PRECONDITION_FAILED",
          message: `Сначала завершите контрольную «${active.title}».`,
        });
      }
      // уже завершена — второй раз нельзя
      const done = await db
        .select({ id: examWorkAttempts.id })
        .from(examWorkAttempts)
        .where(
          and(
            eq(examWorkAttempts.workId, input.workId),
            eq(examWorkAttempts.userId, ctx.user.id),
            sql`${examWorkAttempts.finishedAt} is not null`,
          ),
        )
        .limit(1);
      if (done.length > 0) {
        throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Вы уже сдали эту контрольную." });
      }
      if (!active) {
        await db.insert(examWorkAttempts).values({ workId: input.workId, userId: ctx.user.id });
        void notifyTeacherSafe(`📝 Начата контрольная\n👤 ${ctx.user.name ?? "Ученик"}\n📋 ${work.title}`);
      }
      const tasks = await db
        .select({ id: examWorkTasks.id, question: examWorkTasks.question })
        .from(examWorkTasks)
        .where(eq(examWorkTasks.workId, input.workId))
        .orderBy(examWorkTasks.orderIndex);
      return { title: work.title, questions: tasks.map((t) => ({ taskId: t.id, question: t.question })) };
    }),

  /** Сдача контрольной: проверка без показа решений, темы открываются снова */
  submit: authedQuery
    .input(
      z.object({
        workId: z.number().int().positive(),
        answers: z
          .array(z.object({ taskId: z.number().int().positive(), answer: z.string().max(500) }))
          .min(1)
          .max(30),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const [attempt] = await db
        .select()
        .from(examWorkAttempts)
        .where(
          and(
            eq(examWorkAttempts.workId, input.workId),
            eq(examWorkAttempts.userId, ctx.user.id),
            sql`${examWorkAttempts.finishedAt} is null`,
          ),
        )
        .limit(1);
      if (!attempt) {
        throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Нет активной попытки — сначала начните контрольную." });
      }
      const tasks = await db
        .select()
        .from(examWorkTasks)
        .where(eq(examWorkTasks.workId, input.workId));
      const byId = new Map(tasks.map((t) => [t.id, t]));

      let correct = 0;
      const details: { taskId: number; given: string; correct: boolean }[] = [];
      for (const a of input.answers) {
        const task = byId.get(a.taskId);
        if (!task) continue;
        const ok = a.answer.trim().length > 0 && answersEqual(a.answer, task.answer);
        if (ok) correct++;
        details.push({ taskId: a.taskId, given: a.answer.trim() || "—", correct: ok });
      }
      const total = details.length;
      if (total === 0) throw new TRPCError({ code: "NOT_FOUND", message: "Задания не найдены." });

      await db
        .update(examWorkAttempts)
        .set({ finishedAt: new Date(), correct, total, details })
        .where(eq(examWorkAttempts.id, attempt.id));

      const [work] = await db.select().from(examWorks).where(eq(examWorks.id, input.workId)).limit(1);
      const pct = Math.round((correct / total) * 100);
      void notifyTeacherSafe(
        `✅ Контрольная сдана\n👤 ${ctx.user.name ?? "Ученик"}\n📋 ${work?.title ?? input.workId}\n✏️ Верно: ${correct} из ${total} (${pct}%)`,
      );

      // Ученику — только балл, без правильных ответов и решений
      return { correct, total };
    }),
});
