import { eq } from "drizzle-orm";
import * as schema from "@db/schema";
import type { InsertUser } from "@db/schema";
import { getDb } from "./connection";
import { env } from "../lib/env";

/** Длительность пробного периода для новых учеников (7 дней) */
export const TRIAL_DAYS = 7;

export async function findUserByUnionId(unionId: string) {
  const rows = await getDb()
    .select()
    .from(schema.users)
    .where(eq(schema.users.unionId, unionId))
    .limit(1);
  return rows.at(0);
}

export async function upsertUser(data: InsertUser) {
  const values = { ...data };
  const updateSet: Partial<InsertUser> = {
    lastSignInAt: new Date(),
    ...data,
  };

  if (
    values.role === undefined &&
    values.unionId &&
    values.unionId === env.ownerUnionId
  ) {
    values.role = "admin";
    updateSet.role = "admin";
  }

  // Новый пользователь (не админ): включаем пробный период — неделя бесплатного доступа.
  // При повторных входах пробу не перезаписываем: поля есть только в insert-значениях.
  if (values.unionId && values.accessUntil === undefined) {
    const existing = await findUserByUnionId(values.unionId);
    if (!existing && values.role !== "admin") {
      values.accessUntil = new Date(Date.now() + TRIAL_DAYS * 24 * 60 * 60 * 1000);
      values.trialGranted = true;
    }
  }

  await getDb()
    .insert(schema.users)
    .values(values)
    .onDuplicateKeyUpdate({ set: updateSet });
}
