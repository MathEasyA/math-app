import { and, eq, sql } from "drizzle-orm";
import { TRPCError } from "@trpc/server";

import { examWorkAttempts, examWorks } from "@db/schema";
import { getDb } from "./connection";

/**
 * Активная (начатая, но не завершённая) контрольная ученика.
 * Пока такая есть — доступ к темам и практике закрыт, чтобы не подглядывать.
 */
export async function getActiveExamAttempt(userId: number) {
  const db = getDb();
  const rows = await db
    .select({
      attemptId: examWorkAttempts.id,
      workId: examWorks.id,
      title: examWorks.title,
      grade: examWorks.grade,
    })
    .from(examWorkAttempts)
    .innerJoin(examWorks, eq(examWorks.id, examWorkAttempts.workId))
    .where(and(eq(examWorkAttempts.userId, userId), sql`${examWorkAttempts.finishedAt} is null`))
    .limit(1);
  return rows[0] ?? null;
}

/** Бросает ошибку, если у ученика идёт контрольная работа */
export async function requireNoActiveExamWork(user: { id: number; role: string }) {
  if (user.role === "admin") return;
  const active = await getActiveExamAttempt(user.id);
  if (active) {
    throw new TRPCError({
      code: "PRECONDITION_FAILED",
      message: `Идёт контрольная работа «${active.title}» — доступ к темам закрыт до её завершения.`,
    });
  }
}
