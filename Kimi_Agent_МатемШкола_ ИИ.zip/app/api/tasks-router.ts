import { generateObject } from "ai";
import { and, desc, eq, sql } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { z } from "zod";

import { findGrade, findPracticeTarget, gradeOfSectionId } from "@contracts/content";
import { attempts, tasks, theoryReads, topicTests } from "@db/schema";
import { getDb } from "./queries/connection";
import { authedQuery, createRouter } from "./middleware";
import { kimiGw } from "./ai/provider";
import {
  AiUnavailable,
  AiMisconfigured,
  ContentRejected,
  classifyAiError,
  listModels,
} from "./lib/ai-client";
import { hasAccess, maybeSendTopicReport } from "./teacher-router";
import { requireNoActiveExamWork } from "./queries/exam-works";

function requireAccess(user: { role: string; accessUntil: Date | null }) {
  if (!hasAccess(user)) {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "Доступ к практике закрыт. Свяжитесь с учителем, чтобы оплатить доступ.",
    });
  }
}

/**
 * Доступ к практике по теме.
 * — Учитель (admin): без ограничений.
 * — Экзамены (ОГЭ/ЕГЭ): открытый банк заданий в обоих режимах.
 * — Свободный режим (learningMode = "free"): все классы и темы открыты.
 * — Обучение (learningMode = "course"): только свой класс, только после входного
 *   тестирования; темы открываются по порядку — новая тема доступна, когда по всем
 *   предыдущим темам сдан тест; практика по теме — после изучения теории и сдачи
 *   теста по ней (ошибок не больше 20 %).
 */
async function requireTopicUnlocked(
  user: {
    id: number;
    role: string;
    grade: number | null;
    learningMode: "free" | "course" | null;
    placementDone: boolean;
  },
  sectionId: string,
  topicId: string,
) {
  if (user.role === "admin") return;

  const grade = gradeOfSectionId(sectionId);
  if (grade == null) return; // экзамены и прочие секции — открытый банк
  if (user.learningMode !== "course") return; // свободный режим — всё открыто

  if (!user.placementDone) {
    throw new TRPCError({
      code: "PRECONDITION_FAILED",
      message: "Сначала пройдите входное тестирование на главной странице.",
    });
  }
  if (user.grade !== grade) {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "Это раздел другого класса. После входного тестирования вам открыт ваш класс.",
    });
  }

  const db = getDb();
  const g = findGrade(grade);
  const idx = g ? g.topics.findIndex((t) => t.id === topicId) : -1;

  // Последовательное открытие: все предыдущие темы должны быть сданы
  if (g && idx > 0) {
    const passedRows = await db
      .select({ topicId: topicTests.topicId })
      .from(topicTests)
      .where(
        and(
          eq(topicTests.userId, user.id),
          eq(topicTests.sectionId, sectionId),
          eq(topicTests.passed, true),
        ),
      );
    const passedSet = new Set(passedRows.map((r) => r.topicId));
    const missing = g.topics.slice(0, idx).find((t) => !passedSet.has(t.id));
    if (missing) {
      throw new TRPCError({
        code: "PRECONDITION_FAILED",
        message: `Эта тема пока закрыта. Сначала завершите предыдущую тему «${missing.title}»: изучите теорию и сдайте тест.`,
      });
    }
  }

  const read = await db
    .select({ id: theoryReads.id })
    .from(theoryReads)
    .where(and(eq(theoryReads.userId, user.id), eq(theoryReads.sectionId, sectionId), eq(theoryReads.topicId, topicId)))
    .limit(1);
  if (read.length === 0) {
    throw new TRPCError({
      code: "PRECONDITION_FAILED",
      message: "Практика откроется после изучения теории: прочитайте тему и нажмите «Теория изучена».",
    });
  }
  const passed = await db
    .select({ id: topicTests.id })
    .from(topicTests)
    .where(and(eq(topicTests.userId, user.id), eq(topicTests.sectionId, sectionId), eq(topicTests.topicId, topicId), eq(topicTests.passed, true)))
    .limit(1);
  if (passed.length === 0) {
    throw new TRPCError({
      code: "PRECONDITION_FAILED",
      message: "Практика откроется после теста по теме: нужно ошибиться не больше чем в 20% заданий.",
    });
  }
}

const taskSchema = z.object({
  question: z
    .string()
    .describe("Условие задачи на русском языке, формулы в LaTeX внутри $...$"),
  answer: z
    .string()
    .describe("Краткий ответ: одно число или простая дробь вида a/b, без единиц измерения и пояснений"),
  solution: z
    .string()
    .describe("Краткое пошаговое решение на русском (3–6 шагов), формулы в LaTeX внутри $...$"),
});

const difficultyInput = z.object({
  sectionId: z.string().min(1).max(32),
  topicId: z.string().min(1).max(64),
  difficulty: z.number().int().min(1).max(3).default(2),
});

const DIFFICULTY_TEXT: Record<number, string> = {
  1: "лёгкий уровень (базовое задание, одно действие)",
  2: "средний уровень (типовое задание, два-три действия)",
  3: "сложный уровень (повышенная сложность, требует комбинации приёмов)",
};

function buildPrompt(sectionTitle: string, topicTitle: string, topicDescription: string, difficulty: number) {
  return [
    `Ты — составитель задач по школьной математике. Придумай НОВУЮ оригинальную задачу.`,
    `Раздел: ${sectionTitle}. Тема: «${topicTitle}» (${topicDescription}).`,
    `Сложность: ${DIFFICULTY_TEXT[difficulty]}.`,
    ``,
    `Требования:`,
    `- задача должна иметь единственный однозначный ответ;`,
    `- ответ — конкретное число (целое, десятичная дробь или обыкновенная дробь вида a/b), без единиц измерения;`,
    `- числа в условии подбирай так, чтобы решение было «красивым», без монструозных вычислений;`,
    `- формулы в условии и решении записывай в LaTeX между знаками $...$;`,
    `- не используй буквенные ответы и варианты «выберите из списка» — только вычислительная задача;`,
    `- в решении: 3–6 коротких шагов, финальная строка «Ответ: …».`,
    `- КРИТИЧЕСКИ ВАЖНО: поле answer должно совпадать с числом в финальной строке «Ответ: …». Реши задачу, проверь подстановкой и только потом записывай answer.`,
  ].join("\n");
}

/** Извлекает финальный ответ из текста решения («Ответ: 12» / «Ответ: $12$») */
function extractFinalAnswer(solution: string): string | null {
  const matches = [...solution.matchAll(/ответ\s*[:—–-]\s*\$?\\?[^\s$.,;]{1,40}/giu)];
  if (matches.length === 0) return null;
  const last = matches[matches.length - 1][0];
  return last
    .replace(/ответ\s*[:—–-]\s*/iu, "")
    .replace(/[$\\{}]/g, "")
    .replace(/\\text\{[^}]*\}/g, "")
    .trim() || null;
}

/** Нормализация ответа для сравнения: строки и числовая эквивалентность (включая дроби) */
function normalizeAnswer(raw: string): string {
  return raw
    .toLowerCase()
    .trim()
    .replace(/\s+/g, "")
    .replace(/,/g, ".")
    .replace(/[−–—]/g, "-")
    .replace(/[=\\]|[а-я]*$/u, (m) => (/[а-я]/u.test(m) ? "" : m));
}

function numericValue(raw: string): number | null {
  const s = normalizeAnswer(raw);
  const frac = s.match(/^(-?\d+(?:\.\d+)?)\/(-?\d+(?:\.\d+)?)$/);
  if (frac) {
    const denom = Number(frac[2]);
    if (denom === 0) return null;
    return Number(frac[1]) / denom;
  }
  const n = Number(s);
  return Number.isFinite(n) && s !== "" ? n : null;
}

export function answersEqual(given: string, correct: string): boolean {
  const g = normalizeAnswer(given);
  const c = normalizeAnswer(correct);
  if (g === c) return true;
  const gn = numericValue(given);
  const cn = numericValue(correct);
  if (gn !== null && cn !== null) return Math.abs(gn - cn) < 1e-6;
  return false;
}

export function toUserFacingError(err: unknown): TRPCError {
  const classified = classifyAiError(err);
  if (classified instanceof AiUnavailable) {
    return new TRPCError({
      code: "FORBIDDEN",
      message: "Квота ИИ исчерпана. Генерация заданий временно недоступна — попросите учителя пополнить баланс в Kimi.",
    });
  }
  if (classified instanceof AiMisconfigured) {
    return new TRPCError({
      code: "PRECONDITION_FAILED",
      message: "ИИ не настроен на этом сайте: нужно один раз опубликовать (или переоткрыть) сайт и попробовать снова.",
    });
  }
  if (classified instanceof ContentRejected) {
    return new TRPCError({
      code: "BAD_REQUEST",
      message: "Генерация отклонена модерацией. Попробуйте ещё раз — задача будет другой.",
    });
  }
  return new TRPCError({
    code: "INTERNAL_SERVER_ERROR",
    message: "Не удалось сгенерировать задание. Повторите попытку через несколько секунд.",
  });
}

export const tasksRouter = createRouter({
  generate: authedQuery
    .input(difficultyInput)
    .mutation(async ({ ctx, input }) => {
      requireAccess(ctx.user);
      const target = findPracticeTarget(input.sectionId, input.topicId);
      if (!target) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Тема не найдена." });
      }
      await requireNoActiveExamWork(ctx.user);
      await requireTopicUnlocked(ctx.user, input.sectionId, input.topicId);

      let object: z.infer<typeof taskSchema>;
      try {
        const { defaultModelId } = await listModels();
        const prompt = buildPrompt(
          target.sectionTitle,
          target.topicTitle,
          target.topicDescription,
          input.difficulty,
        );

        // До двух попыток: сверяем поле answer с финальным «Ответ: …» в решении
        let generated: z.infer<typeof taskSchema> | null = null;
        for (let attemptNo = 0; attemptNo < 2; attemptNo++) {
          const result = await generateObject({
            model: kimiGw(defaultModelId),
            schema: taskSchema,
            prompt,
            providerOptions: {
              "kimi-gw": { max_completion_tokens: 2500 },
            },
          });
          generated = result.object;
          const finalAnswer = extractFinalAnswer(generated.solution);
          if (!finalAnswer || answersEqual(generated.answer, finalAnswer)) {
            break; // согласовано
          }
          if (attemptNo === 1) {
            // вторая попытка тоже разошлась — доверяем финальной строке решения
            generated = { ...generated, answer: finalAnswer };
          }
        }
        object = generated!;
      } catch (err) {
        throw toUserFacingError(err);
      }

      const db = getDb();
      const inserted = await db.insert(tasks).values({
        userId: ctx.user.id,
        sectionId: input.sectionId,
        topicId: input.topicId,
        difficulty: input.difficulty,
        question: object.question,
        answer: object.answer,
        solution: object.solution,
      });

      return {
        taskId: Number(inserted[0].insertId),
        question: object.question,
        difficulty: input.difficulty,
      };
    }),

  check: authedQuery
    .input(
      z.object({
        taskId: z.number().int().positive(),
        answer: z.string().min(1, "Введите ответ").max(500),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      requireAccess(ctx.user);
      const db = getDb();
      const [task] = await db
        .select()
        .from(tasks)
        .where(and(eq(tasks.id, input.taskId), eq(tasks.userId, ctx.user.id)))
        .limit(1);
      if (!task) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Задание не найдено." });
      }
      if (task.sectionId !== "placement") {
        await requireNoActiveExamWork(ctx.user);
        await requireTopicUnlocked(ctx.user, task.sectionId, task.topicId);
      }

      const correct = answersEqual(input.answer, task.answer);
      await db.insert(attempts).values({
        userId: ctx.user.id,
        taskId: task.id,
        sectionId: task.sectionId,
        topicId: task.topicId,
        givenAnswer: input.answer.slice(0, 500),
        correct,
      });

      // Отчёт учителю после пройденного блока (каждые 5 заданий по теме) — в фоне
      void maybeSendTopicReport({
        userId: ctx.user.id,
        userName: ctx.user.name,
        sectionId: task.sectionId,
        topicId: task.topicId,
      }).catch(() => {});

      return { correct, answer: task.answer, solution: task.solution };
    }),

  /** Прогресс ученика: по разделам и темам */
  progress: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const rows = await db
      .select({
        sectionId: attempts.sectionId,
        topicId: attempts.topicId,
        total: sql<number>`count(*)`.mapWith(Number),
        correct: sql<number>`sum(${attempts.correct})`.mapWith(Number),
      })
      .from(attempts)
      .where(eq(attempts.userId, ctx.user.id))
      .groupBy(attempts.sectionId, attempts.topicId);

    return rows;
  }),

  /** Последние попытки (для страницы прогресса) */
  recentAttempts: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const rows = await db
      .select({
        id: attempts.id,
        sectionId: attempts.sectionId,
        topicId: attempts.topicId,
        givenAnswer: attempts.givenAnswer,
        correct: attempts.correct,
        createdAt: attempts.createdAt,
        question: tasks.question,
      })
      .from(attempts)
      .innerJoin(tasks, eq(attempts.taskId, tasks.id))
      .where(eq(attempts.userId, ctx.user.id))
      .orderBy(desc(attempts.createdAt))
      .limit(12);
    return rows;
  }),
});
