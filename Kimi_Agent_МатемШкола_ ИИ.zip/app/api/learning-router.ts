import { generateObject } from "ai";
import { and, desc, eq, sql } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { z } from "zod";

import { exams, findGrade, findPracticeTarget, gradeOfSectionId, grades } from "@contracts/content";
import { attempts, tasks, theoryReads, topicTests, users } from "@db/schema";
import { getDb } from "./queries/connection";
import { getActiveExamAttempt, requireNoActiveExamWork } from "./queries/exam-works";
import { adminQuery, authedQuery, createRouter } from "./middleware";
import { kimiGw } from "./ai/provider";
import { listModels } from "./lib/ai-client";
import { hasAccess } from "./teacher-router";
import { answersEqual, toUserFacingError } from "./tasks-router";
import { notifyTeacher } from "./lib/telegram";

/** Уведомление учителю, не роняет запрос при ошибке */
function notifyTeacherSafe(text: string): Promise<boolean> {
  return notifyTeacher(text).catch(() => false);
}

/** Заданий в тесте по теме */
const TOPIC_TEST_COUNT = 5;
/** Максимальная доля ошибок для зачёта теста */
const MAX_ERROR_RATE = 0.2;

function requireAccess(user: { role: string; accessUntil: Date | null }) {
  if (!hasAccess(user)) {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "Доступ к практике закрыт. Свяжитесь с учителем, чтобы оплатить доступ.",
    });
  }
}

type GateUser = {
  id: number;
  role: string;
  grade: number | null;
  learningMode: "free" | "course" | null;
  placementDone: boolean;
};

/** Режим «обучение»: последовательное открытие тем, гейты активны */
function isCourseMode(user: { role: string; learningMode: "free" | "course" | null }) {
  return user.role !== "admin" && user.learningMode === "course";
}

/** Ученик, у которого ещё не пройдено входное тестирование (только в режиме обучения) */
function requirePlacementDone(user: GateUser) {
  if (!isCourseMode(user)) return;
  if (!user.placementDone) {
    throw new TRPCError({
      code: "PRECONDITION_FAILED",
      message: "Сначала пройдите входное тестирование на главной странице.",
    });
  }
}

function requireOwnGrade(user: GateUser, sectionId: string) {
  if (!isCourseMode(user)) return; // свободный режим и учитель — все разделы открыты
  const grade = gradeOfSectionId(sectionId);
  if (grade == null) return; // экзамены доступны всем
  if (user.grade !== grade) {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "Это раздел другого класса. Ваш класс открывается после входного тестирования.",
    });
  }
}

/**
 * Режим «обучение»: тема открывается, только когда по всем предыдущим темам
 * класса сдан тест. Возвращает true, если тема открыта для изучения.
 */
async function isTopicOpen(user: GateUser, sectionId: string, topicId: string): Promise<boolean> {
  if (!isCourseMode(user)) return true;
  const grade = gradeOfSectionId(sectionId);
  if (grade == null) return true;
  if (!user.placementDone) return false;
  if (user.grade !== grade) return false;
  const g = findGrade(grade);
  const idx = g ? g.topics.findIndex((t) => t.id === topicId) : -1;
  if (!g || idx < 0) return false;
  if (idx === 0) return true;
  const db = getDb();
  const passedRows = await db
    .select({ topicId: topicTests.topicId })
    .from(topicTests)
    .where(
      and(
        eq(topicTests.userId, user.id),
        eq(topicTests.sectionId, sectionId),
        eq(topicTests.passed, true),
      ),
    );
  const passedSet = new Set(passedRows.map((r) => r.topicId));
  return g.topics.slice(0, idx).every((t) => passedSet.has(t.id));
}

/** Бросает ошибку, если тема ещё закрыта последовательным гейтом */
async function requireTopicOpen(user: GateUser, sectionId: string, topicId: string) {
  if (!(await isTopicOpen(user, sectionId, topicId))) {
    const grade = gradeOfSectionId(sectionId);
    const g = grade != null ? findGrade(grade) : undefined;
    const idx = g ? g.topics.findIndex((t) => t.id === topicId) : -1;
    const prev = g && idx > 0 ? g.topics[idx - 1] : null;
    throw new TRPCError({
      code: "PRECONDITION_FAILED",
      message: prev
        ? `Тема откроется после того, как будет сдан тест по предыдущей теме «${prev.title}».`
        : "Тема пока закрыта. Пройдите входное тестирование и предыдущие темы.",
    });
  }
}

const genTaskSchema = z.object({
  question: z.string().describe("Условие задачи на русском, формулы в LaTeX внутри $...$"),
  answer: z.string().describe("Краткий ответ: число или дробь a/b, без единиц и пояснений"),
  solution: z.string().describe("Краткое решение 2–5 шагов, финальная строка «Ответ: …»"),
});

async function generateTask(prompt: string): Promise<z.infer<typeof genTaskSchema>> {
  const { defaultModelId } = await listModels();
  const result = await generateObject({
    model: kimiGw(defaultModelId),
    schema: genTaskSchema,
    prompt,
    providerOptions: { "kimi-gw": { max_completion_tokens: 2500 } },
  });
  return result.object;
}

const placementQuizSchema = z.object({
  questions: z
    .array(
      z.object({
        topicId: z.string().describe("id темы из списка"),
        question: z.string().describe("Условие задачи на русском, формулы в LaTeX внутри $...$"),
        answer: z.string().describe("Краткий ответ: число или дробь a/b"),
      }),
    )
    .min(4)
    .max(6),
});

export const learningRouter = createRouter({
  /** Указать класс (первый вход) */
  setGrade: authedQuery
    .input(z.object({ grade: z.number().int().min(8).max(11) }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db.update(users).set({ grade: input.grade }).where(eq(users.id, ctx.user.id));
      return { ok: true };
    }),

  /**
   * Выбор режима: "free" — свободный банк заданий и тем (всё открыто),
   * "course" — обучение (темы открываются по порядку после тестов, нужен входной тест).
   */
  setMode: authedQuery
    .input(z.object({ mode: z.enum(["free", "course"]) }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user.grade) {
        throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Сначала выберите класс." });
      }
      const db = getDb();
      await db.update(users).set({ learningMode: input.mode }).where(eq(users.id, ctx.user.id));
      const gradeTitle = ctx.user.grade ? findGrade(ctx.user.grade)?.title : null;
      void notifyTeacherSafe(
        `🧭 Ученик выбрал режим\n👤 ${ctx.user.name ?? "Ученик"}\n📚 Класс: ${gradeTitle ?? ctx.user.grade ?? "?"}\nРежим: ${input.mode === "free" ? "свободный банк заданий" : "обучение (поэтапно)"}`,
      );
      return { ok: true };
    }),

  /**
   * План входного теста: по 1–2 задания из каждого класса НИЖЕ класса ученика
   * (7 класс и младше в курсе нет — берём самые базовые темы 8-го).
   */
  placementPlan: authedQuery.query(({ ctx }) => {
    const grade = ctx.user.grade;
    if (!grade) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Сначала выберите класс." });
    const plan: { topicId: string; topicTitle: string; grade: number; count: number }[] = [];
    if (grade > 8) {
      for (const g of grades.filter((g) => g.grade < grade)) {
        const picked = [...g.topics].sort(() => Math.random() - 0.5).slice(0, 2);
        for (const t of picked) {
          plan.push({ topicId: t.id, topicTitle: t.title, grade: g.grade, count: 1 });
        }
      }
    } else {
      // 8 класс: базовые темы 8-го (знания «прошлых лет» 5–7 классов проверяем через них)
      for (const t of grades[0].topics.slice(0, 4)) {
        plan.push({ topicId: t.id, topicTitle: t.title, grade: 8, count: 1 });
      }
    }
    return { grade, tasks: plan };
  }),

  /** Сгенерировать задание входного теста по теме */
  placementTask: authedQuery
    .input(z.object({ topicId: z.string().min(1).max(64) }))
    .mutation(async ({ ctx, input }) => {
      // тема входного теста может быть из любого класса ≤ класса ученика
      const grade = ctx.user.grade;
      if (!grade) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Сначала выберите класс." });
      const sourceGrade = [...grades].reverse().find((g) => g.topics.some((t) => t.id === input.topicId));
      const topic = sourceGrade?.topics.find((t) => t.id === input.topicId);
      if (!sourceGrade || !topic) throw new TRPCError({ code: "NOT_FOUND", message: "Тема не найдена." });
      if (grade > 8 && sourceGrade.grade >= grade) {
        throw new TRPCError({ code: "FORBIDDEN", message: "Тема не входит во входное тестирование." });
      }

      const prompt = [
        `Ты — составитель задач по школьной математике. Придумай ОДНУ задачу для входного теста ученика, переходящего в ${grade} класс.`,
        `Тема (${sourceGrade.grade} класс): «${topic.title}» (${topic.description}).`,
        `Уровень: базовый, одно-два действия. Ответ — конкретное число или дробь a/b, без единиц измерения.`,
        `Числа подбирай «красивые». Формулы — в LaTeX между $...$. Финальная строка решения: «Ответ: …».`,
      ].join("\n");

      let object: z.infer<typeof genTaskSchema>;
      try {
        object = await generateTask(prompt);
      } catch (err) {
        throw toUserFacingError(err);
      }
      const db = getDb();
      const inserted = await db.insert(tasks).values({
        userId: ctx.user.id,
        sectionId: "placement",
        topicId: input.topicId,
        difficulty: 1,
        question: object.question,
        answer: object.answer,
        solution: object.solution,
      });
      return { taskId: Number(inserted[0].insertId), question: object.question };
    }),

  /** Ответ на задание входного теста (ничего не записываем в прогресс) */
  placementCheck: authedQuery
    .input(z.object({ taskId: z.number().int().positive(), answer: z.string().min(1).max(500) }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const [task] = await db
        .select()
        .from(tasks)
        .where(and(eq(tasks.id, input.taskId), eq(tasks.userId, ctx.user.id), eq(tasks.sectionId, "placement")))
        .limit(1);
      if (!task) throw new TRPCError({ code: "NOT_FOUND", message: "Задание не найдено." });
      return { correct: answersEqual(input.answer, task.answer), answer: task.answer, solution: task.solution };
    }),

  /** Завершить входное тестирование: сохранить результат, открыть класс */
  placementFinish: authedQuery
    .input(z.object({ correct: z.number().int().min(0), total: z.number().int().min(1).max(20) }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db
        .update(users)
        .set({ placementDone: true, placementScore: input.correct, placementTotal: input.total })
        .where(eq(users.id, ctx.user.id));
      const gradeTitle = ctx.user.grade ? findGrade(ctx.user.grade)?.title : null;
      void notifyTeacherSafe(
        `🎓 Входное тестирование пройдено\n👤 ${ctx.user.name ?? "Ученик"}\n📚 Класс: ${gradeTitle ?? ctx.user.grade ?? "?"}\n✏️ Результат: ${input.correct} из ${input.total} (${Math.round((input.correct / input.total) * 100)}%)`,
      );
      return { ok: true };
    }),

  /** Отметить теорию темы изученной */
  markTheoryRead: authedQuery
    .input(z.object({ sectionId: z.string().min(1).max(32), topicId: z.string().min(1).max(64) }))
    .mutation(async ({ ctx, input }) => {
      requireAccess(ctx.user);
      await requireNoActiveExamWork(ctx.user);
      requirePlacementDone(ctx.user);
      requireOwnGrade(ctx.user, input.sectionId);
      if (!findPracticeTarget(input.sectionId, input.topicId)) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Тема не найдена." });
      }
      await requireTopicOpen(ctx.user, input.sectionId, input.topicId);
      const db = getDb();
      const existing = await db
        .select({ id: theoryReads.id })
        .from(theoryReads)
        .where(
          and(
            eq(theoryReads.userId, ctx.user.id),
            eq(theoryReads.sectionId, input.sectionId),
            eq(theoryReads.topicId, input.topicId),
          ),
        )
        .limit(1);
      if (existing.length === 0) {
        await db.insert(theoryReads).values({
          userId: ctx.user.id,
          sectionId: input.sectionId,
          topicId: input.topicId,
        });
      }
      return { ok: true };
    }),

  /** Статус тем: изучена ли теория, пройден ли тест (по всем темам ученика) */
  topicStatuses: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const reads = await db
      .select({ sectionId: theoryReads.sectionId, topicId: theoryReads.topicId })
      .from(theoryReads)
      .where(eq(theoryReads.userId, ctx.user.id));
    const tests = await db
      .select({ sectionId: topicTests.sectionId, topicId: topicTests.topicId, passed: topicTests.passed })
      .from(topicTests)
      .where(eq(topicTests.userId, ctx.user.id))
      .orderBy(desc(topicTests.createdAt));

    const passedSet = new Set<string>();
    for (const t of tests) {
      const key = `${t.sectionId}:${t.topicId}`;
      if (!passedSet.has(key) && t.passed) passedSet.add(key);
    }
    return {
      theoryRead: reads.map((r) => `${r.sectionId}:${r.topicId}`),
      testPassed: [...passedSet],
    };
  }),

  /**
   * Статус темы для UI:
   * — topicOpen: доступна ли теория темы (в режиме обучения — после сдачи предыдущих тем);
   * — unlocked: доступна ли практика (в обучении — теория + сданный тест; в свободном режиме — всегда);
   * — theoryRead / testPassed / lastTest — детали прогресса.
   */
  topicGate: authedQuery
    .input(z.object({ sectionId: z.string().min(1).max(32), topicId: z.string().min(1).max(64) }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const key = { userId: ctx.user.id, sectionId: input.sectionId, topicId: input.topicId };
      const read = await db
        .select({ id: theoryReads.id })
        .from(theoryReads)
        .where(and(eq(theoryReads.userId, key.userId), eq(theoryReads.sectionId, key.sectionId), eq(theoryReads.topicId, key.topicId)))
        .limit(1);
      const lastTest = await db
        .select()
        .from(topicTests)
        .where(and(eq(topicTests.userId, key.userId), eq(topicTests.sectionId, key.sectionId), eq(topicTests.topicId, key.topicId)))
        .orderBy(desc(topicTests.createdAt))
        .limit(1);
      const t = lastTest[0];
      const theoryRead = read.length > 0;
      const testPassed = t?.passed ?? false;
      const isGradeSection = gradeOfSectionId(input.sectionId) != null;
      const course = isCourseMode(ctx.user) && isGradeSection;
      const topicOpen = course ? await isTopicOpen(ctx.user, input.sectionId, input.topicId) : true;
      const unlocked = course ? topicOpen && theoryRead && testPassed : true;
      // Идёт контрольная — темы и практика временно закрыты
      const exam = ctx.user.role === "admin" ? null : await getActiveExamAttempt(ctx.user.id);
      return {
        mode: ctx.user.role === "admin" ? "admin" : ((ctx.user.learningMode ?? "free") as "free" | "course" | "admin"),
        examWork: exam ? { workId: exam.workId, title: exam.title } : null,
        topicOpen: exam ? false : topicOpen,
        theoryRead,
        testPassed,
        unlocked: exam ? false : unlocked,
        lastTest: t ? { correct: t.correct, total: t.total, passed: t.passed, createdAt: t.createdAt } : null,
        testCount: TOPIC_TEST_COUNT,
        maxErrorRate: MAX_ERROR_RATE,
      };
    }),

  /** Старт теста по теме (доступен после изучения теории) */
  testStart: authedQuery
    .input(z.object({ sectionId: z.string().min(1).max(32), topicId: z.string().min(1).max(64) }))
    .mutation(async ({ ctx, input }) => {
      requireAccess(ctx.user);
      await requireNoActiveExamWork(ctx.user);
      requirePlacementDone(ctx.user);
      requireOwnGrade(ctx.user, input.sectionId);
      const target = findPracticeTarget(input.sectionId, input.topicId);
      if (!target) throw new TRPCError({ code: "NOT_FOUND", message: "Тема не найдена." });
      await requireTopicOpen(ctx.user, input.sectionId, input.topicId);

      const db = getDb();
      const read = await db
        .select({ id: theoryReads.id })
        .from(theoryReads)
        .where(and(eq(theoryReads.userId, ctx.user.id), eq(theoryReads.sectionId, input.sectionId), eq(theoryReads.topicId, input.topicId)))
        .limit(1);
      if (read.length === 0 && ctx.user.role !== "admin") {
        throw new TRPCError({
          code: "PRECONDITION_FAILED",
          message: "Сначала изучите теорию темы и нажмите «Теория изучена».",
        });
      }

      const prompt = [
        `Ты — составитель задач по школьной математике. Составь контрольный тест из ${TOPIC_TEST_COUNT} заданий.`,
        `Раздел: ${target.sectionTitle}. Тема: «${target.topicTitle}» (${target.topicDescription}).`,
        `Уровень: средний (типовые задания). Каждое задание — с единственным ответом: число или дробь a/b, без единиц измерения.`,
        `Задания должны покрывать РАЗНЫЕ аспекты темы. Числа «красивые». Формулы — в LaTeX между $...$.`,
        `Верни строго массив из ${TOPIC_TEST_COUNT} объектов.`,
      ].join("\n");

      let quiz: z.infer<typeof placementQuizSchema>;
      try {
        const { defaultModelId } = await listModels();
        const result = await generateObject({
          model: kimiGw(defaultModelId),
          schema: placementQuizSchema,
          prompt,
          providerOptions: { "kimi-gw": { max_completion_tokens: 6000 } },
        });
        quiz = result.object;
      } catch (err) {
        throw toUserFacingError(err);
      }

      const questions = quiz.questions.slice(0, TOPIC_TEST_COUNT);
      const out: { taskId: number; question: string }[] = [];
      for (const q of questions) {
        const inserted = await db.insert(tasks).values({
          userId: ctx.user.id,
          sectionId: input.sectionId,
          topicId: input.topicId,
          difficulty: 2,
          question: q.question,
          answer: q.answer,
          solution: "Решение будет показано после завершения теста. Ответ: " + q.answer,
        });
        out.push({ taskId: Number(inserted[0].insertId), question: q.question });
      }
      return { questions: out };
    }),

  /** Завершение теста по теме: сверка ответов, запись результата, зачёт при ошибках ≤ 20 % */
  testSubmit: authedQuery
    .input(
      z.object({
        sectionId: z.string().min(1).max(32),
        topicId: z.string().min(1).max(64),
        answers: z
          .array(z.object({ taskId: z.number().int().positive(), answer: z.string().max(500) }))
          .min(1)
          .max(10),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      requireAccess(ctx.user);
      requirePlacementDone(ctx.user);
      requireOwnGrade(ctx.user, input.sectionId);
      const db = getDb();
      const taskIds = input.answers.map((a) => a.taskId);
      const rows = await db
        .select()
        .from(tasks)
        .where(and(eq(tasks.userId, ctx.user.id), sql`${tasks.id} in (${sql.join(taskIds.map((id) => sql`${id}`), sql`, `)})`));
      const byId = new Map(rows.map((r) => [r.id, r]));

      let correct = 0;
      const review: { question: string; given: string; answer: string; correct: boolean }[] = [];
      for (const a of input.answers) {
        const task = byId.get(a.taskId);
        if (!task || task.sectionId !== input.sectionId || task.topicId !== input.topicId) continue;
        const ok = a.answer.trim().length > 0 && answersEqual(a.answer, task.answer);
        if (ok) correct++;
        review.push({ question: task.question, given: a.answer || "—", answer: task.answer, correct: ok });
        await db.insert(attempts).values({
          userId: ctx.user.id,
          taskId: task.id,
          sectionId: task.sectionId,
          topicId: task.topicId,
          givenAnswer: a.answer.slice(0, 500) || "—",
          correct: ok,
        });
      }

      const total = review.length;
      if (total === 0) throw new TRPCError({ code: "NOT_FOUND", message: "Задания теста не найдены." });
      const errorRate = (total - correct) / total;
      const passed = errorRate <= MAX_ERROR_RATE + 1e-9;

      await db.insert(topicTests).values({
        userId: ctx.user.id,
        sectionId: input.sectionId,
        topicId: input.topicId,
        correct,
        total,
        passed,
      });

      const target = findPracticeTarget(input.sectionId, input.topicId);
      const pct = Math.round((correct / total) * 100);
      void notifyTeacherSafe(
        `${passed ? "✅ Тест сдан!" : "❌ Тест не сдан"}\n👤 ${ctx.user.name ?? "Ученик"}\n📚 ${target?.sectionTitle ?? input.sectionId} · ${target?.topicTitle ?? input.topicId}\n✏️ Верно: ${correct} из ${total} (${pct}%)${passed ? "\n🔓 Практика по теме открыта" : "\nДля зачёта нужно не больше 20% ошибок"}`,
      );

      return { correct, total, passed, errorRate: Math.round(errorRate * 100), review };
    }),

  // ---------- Учитель: результат входного теста в карточке ученика ----------

  studentExtra: adminQuery.query(async () => {
    const db = getDb();
    const rows = await db
      .select({
        id: users.id,
        grade: users.grade,
        learningMode: users.learningMode,
        trialGranted: users.trialGranted,
        placementDone: users.placementDone,
        placementScore: users.placementScore,
        placementTotal: users.placementTotal,
      })
      .from(users)
      .where(eq(users.role, "user"));
    const testCounts = await db
      .select({
        userId: topicTests.userId,
        passed: sql<number>`coalesce(sum(${topicTests.passed}),0)`.mapWith(Number),
        total: sql<number>`count(*)`.mapWith(Number),
      })
      .from(topicTests)
      .groupBy(topicTests.userId);
    const byUser = new Map(testCounts.map((t) => [t.userId, t]));
    return rows.map((r) => ({ ...r, topicTestsPassed: byUser.get(r.id)?.passed ?? 0, topicTestsTotal: byUser.get(r.id)?.total ?? 0 }));
  }),
});

/** Список тем для справки (экзамены тоже участвуют в gate) */
export function examSectionIds(): string[] {
  return exams.map((e) => e.id);
}
