import { createOpenAICompatible } from "@ai-sdk/openai-compatible";

// Шлюз платформы: ключ и URL инжектируются в .env, только на сервере.
export const kimiGw = createOpenAICompatible({
  name: "kimi-gw",
  baseURL: process.env.KIMI_AGENTGW_BASE_URL!,
  apiKey: process.env.KIMI_AGENTGW_API_KEY!,
  includeUsage: true,
  supportsStructuredOutputs: true,
});
