import { settings } from "@db/schema";
import { getDb } from "../queries/connection";
import { log } from "./logger";

export async function getSettings() {
  const db = getDb();
  const rows = await db.select().from(settings).limit(1);
  if (rows.length > 0) return rows[0];
  await db.insert(settings).values({});
  const again = await db.select().from(settings).limit(1);
  return again[0];
}

/**
 * Отправка сообщения учителю в Telegram через Bot API.
 * Не бросает ошибки наружу: если Telegram не настроен или недоступен,
 * просто пишет в лог — основной поток (проверка ответа, приём отзыва) не ломается.
 */
export async function notifyTeacher(text: string): Promise<boolean> {
  try {
    const s = await getSettings();
    if (!s.telegramBotToken || !s.telegramChatId) return false;
    const resp = await fetch(
      `https://api.telegram.org/bot${s.telegramBotToken}/sendMessage`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: s.telegramChatId,
          text,
          disable_web_page_preview: true,
        }),
      },
    );
    if (!resp.ok) {
      log.error("telegram sendMessage failed", { status: resp.status });
      return false;
    }
    return true;
  } catch (err) {
    log.error("telegram notify error", { error: String(err) });
    return false;
  }
}
